/**
 * @file JsonCatalogStore.cpp
 * @brief Reading and writing the catalog JSON file with Boost.JSON.
 */
#include "moviebackend/CatalogStore.hpp"

#include "moviebackend/Errors.hpp"
#include "moviebackend/Logging.hpp"
#include "moviebackend/Schedule.hpp"
#include "persistence/JsonHelpers.hpp"

#include <boost/json.hpp>

#include <cstdio>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <system_error>
#include <utility>

namespace moviebackend {

namespace {

/** @brief Read a whole file into a string, or throw PersistenceFailure. */
std::string readWholeFile(const std::string& _path)
{
    // Check that this is a regular file *before* opening it. On Linux,
    // std::ifstream will happily "open" a directory - is_open() returns true
    // and the read then silently yields nothing. Without this guard a catalog
    // path that points at a directory would surface as a confusing "not valid
    // JSON" error instead of naming the real problem.
    std::error_code statError;
    if (!std::filesystem::is_regular_file(_path, statError)) {
        throw ServiceError(ErrorCode::PersistenceFailure,
                           "'" + _path + "' is not a regular file");
    }

    std::ifstream stream(_path.c_str(), std::ios::in | std::ios::binary);
    if (!stream.is_open()) {
        throw ServiceError(ErrorCode::PersistenceFailure,
                           "cannot open '" + _path + "' for reading");
    }

    std::ostringstream buffer;
    buffer << stream.rdbuf();

    if (stream.bad()) {
        throw ServiceError(ErrorCode::PersistenceFailure,
                           "error while reading '" + _path + "'");
    }
    return buffer.str();
}

/* -------------------------------------------------------------------------
 * Deserialisation helpers - one per entity, all following the same shape.
 * ------------------------------------------------------------------------- */

Movie parseMovie(const boost::json::value& _value,
                 const std::string& _origin,
                 const std::string& _path)
{
    using namespace jsonhelpers;

    const boost::json::object& object = *requireObject(_value, _origin, _path);

    Movie movie;
    movie.id = requiredString(object, "id", _origin, _path + ".id");
    movie.title = requiredString(object, "title", _origin, _path + ".title");
    movie.durationMinutes = toInt(
        optionalInt(object, "duration_minutes", 0, _origin, _path + ".duration_minutes"),
        _origin, _path + ".duration_minutes");
    movie.language = optionalString(object, "language", "", _origin, _path + ".language");
    movie.genre = optionalString(object, "genre", "", _origin, _path + ".genre");

    return movie;
}

Theater parseTheater(const boost::json::value& _value,
                     const TheaterDefaults& _defaults,
                     const std::string& _origin,
                     const std::string& _path)
{
    using namespace jsonhelpers;

    const boost::json::object& object = *requireObject(_value, _origin, _path);

    Theater theater;
    theater.id = requiredString(object, "id", _origin, _path + ".id");
    theater.name = requiredString(object, "name", _origin, _path + ".name");
    theater.city = optionalString(object, "city", "", _origin, _path + ".city");

    // Omitting seat_capacity is how a catalog entry asks for the configured
    // default of 20.
    theater.seatCapacity = toInt(
        optionalInt(object, "seat_capacity", _defaults.seatCapacity,
                    _origin, _path + ".seat_capacity"),
        _origin, _path + ".seat_capacity");
    theater.seatsPerRow = toInt(
        optionalInt(object, "seats_per_row", _defaults.seatsPerRow,
                    _origin, _path + ".seats_per_row"),
        _origin, _path + ".seats_per_row");

    return theater;
}

ShowtimeSnapshot parseShowtime(const boost::json::value& _value,
                               const TheaterDefaults& _defaults,
                               const std::string& _origin,
                               const std::string& _path)
{
    using namespace jsonhelpers;

    const boost::json::object& object = *requireObject(_value, _origin, _path);

    ShowtimeSnapshot entry;
    entry.showtime.id = requiredString(object, "id", _origin, _path + ".id");
    entry.showtime.movieId = requiredString(object, "movie_id", _origin, _path + ".movie_id");
    entry.showtime.theaterId = requiredString(object, "theater_id", _origin,
                                              _path + ".theater_id");

    const std::string startText =
        requiredString(object, "start_time", _origin, _path + ".start_time");
    entry.showtime.startTime = schedule::parseTimeOfDay(startText);

    entry.showtime.seatCapacity = toInt(
        optionalInt(object, "seat_capacity", _defaults.seatCapacity,
                    _origin, _path + ".seat_capacity"),
        _origin, _path + ".seat_capacity");
    entry.showtime.seatsPerRow = toInt(
        optionalInt(object, "seats_per_row", _defaults.seatsPerRow,
                    _origin, _path + ".seats_per_row"),
        _origin, _path + ".seats_per_row");

    const boost::json::array* booked =
        optionalArray(object, "booked_seats", _origin, _path + ".booked_seats");
    if (booked != nullptr) {
        for (std::size_t i = 0; i < booked->size(); ++i) {
            const boost::json::value& seat = (*booked)[i];
            if (!seat.is_string()) {
                throw invalidArgument(where(_origin, _path + ".booked_seats")
                                      + " must contain only strings");
            }
            const boost::json::string& text = seat.get_string();
            entry.bookedSeats.push_back(std::string(text.c_str(), text.size()));
        }
    }

    return entry;
}

Booking parseBooking(const boost::json::value& _value,
                     const std::string& _origin,
                     const std::string& _path)
{
    using namespace jsonhelpers;

    const boost::json::object& object = *requireObject(_value, _origin, _path);

    Booking booking;
    booking.id = requiredString(object, "id", _origin, _path + ".id");
    booking.showtimeId = requiredString(object, "showtime_id", _origin,
                                        _path + ".showtime_id");
    booking.customerName = optionalString(object, "customer_name", "", _origin,
                                          _path + ".customer_name");
    booking.createdAtEpochSeconds =
        optionalInt(object, "created_at", 0, _origin, _path + ".created_at");

    const boost::json::array* seats =
        optionalArray(object, "seats", _origin, _path + ".seats");
    if (seats != nullptr) {
        for (std::size_t i = 0; i < seats->size(); ++i) {
            const boost::json::value& seat = (*seats)[i];
            if (!seat.is_string()) {
                throw invalidArgument(where(_origin, _path + ".seats")
                                      + " must contain only strings");
            }
            const boost::json::string& text = seat.get_string();
            booking.seats.push_back(std::string(text.c_str(), text.size()));
        }
    }

    return booking;
}

/* -------------------------------------------------------------------------
 * Serialisation helpers
 * ------------------------------------------------------------------------- */

boost::json::array toJsonArray(const std::vector<SeatLabel>& _labels)
{
    boost::json::array result;
    result.reserve(_labels.size());
    for (std::size_t i = 0; i < _labels.size(); ++i) {
        result.push_back(boost::json::value(_labels[i]));
    }
    return result;
}

/**
 * @brief Pretty-print a Boost.JSON value.
 *
 * Boost.JSON's serializer emits one dense line. The catalog file is meant to
 * be hand-edited, so it is printed with indentation instead. Written as an
 * explicit recursive function rather than pulled from a library because it is
 * short and keeps the dependency surface at exactly "Boost.JSON".
 */
void prettyPrint(std::ostream& _out, const boost::json::value& _value, int _indent)
{
    const std::string pad(static_cast<std::size_t>(_indent) * 2U, ' ');
    const std::string padInner(static_cast<std::size_t>(_indent + 1) * 2U, ' ');

    switch (_value.kind()) {
        case boost::json::kind::object: {
            const boost::json::object& object = _value.get_object();
            if (object.empty()) {
                _out << "{}";
                return;
            }
            _out << "{\n";
            bool first = true;
            for (boost::json::object::const_iterator it = object.begin();
                 it != object.end(); ++it) {
                if (!first) {
                    _out << ",\n";
                }
                first = false;
                _out << padInner << boost::json::serialize(it->key()) << ": ";
                prettyPrint(_out, it->value(), _indent + 1);
            }
            _out << "\n" << pad << "}";
            return;
        }
        case boost::json::kind::array: {
            const boost::json::array& array = _value.get_array();
            if (array.empty()) {
                _out << "[]";
                return;
            }
            _out << "[\n";
            for (std::size_t i = 0; i < array.size(); ++i) {
                if (i > 0) {
                    _out << ",\n";
                }
                _out << padInner;
                prettyPrint(_out, array[i], _indent + 1);
            }
            _out << "\n" << pad << "]";
            return;
        }
        default:
            _out << boost::json::serialize(_value);
            return;
    }
}

} // unnamed namespace

/* =========================================================================
 * JsonCatalogStore
 * ========================================================================= */

JsonCatalogStore::JsonCatalogStore(std::string _path, const TheaterDefaults& _defaults)
    : m_path(std::move(_path))
    , m_defaults(_defaults)
{
}

CatalogSnapshot JsonCatalogStore::parse(const std::string& _json,
                                        const TheaterDefaults& _defaults,
                                        const std::string& _originForErrors)
{
    using namespace jsonhelpers;

    CatalogSnapshot snapshot;

    const boost::json::value document = parseDocument(_json, _originForErrors);
    const boost::json::object& root = *requireObject(document, _originForErrors, "<root>");

    const boost::json::array* movies = optionalArray(root, "movies", _originForErrors, "movies");
    if (movies != nullptr) {
        for (std::size_t i = 0; i < movies->size(); ++i) {
            snapshot.movies.push_back(parseMovie(
                (*movies)[i], _originForErrors, "movies[" + std::to_string(i) + "]"));
        }
    }

    const boost::json::array* theaters =
        optionalArray(root, "theaters", _originForErrors, "theaters");
    if (theaters != nullptr) {
        for (std::size_t i = 0; i < theaters->size(); ++i) {
            snapshot.theaters.push_back(parseTheater(
                (*theaters)[i], _defaults, _originForErrors,
                "theaters[" + std::to_string(i) + "]"));
        }
    }

    const boost::json::array* showtimes =
        optionalArray(root, "showtimes", _originForErrors, "showtimes");
    if (showtimes != nullptr) {
        for (std::size_t i = 0; i < showtimes->size(); ++i) {
            snapshot.showtimes.push_back(parseShowtime(
                (*showtimes)[i], _defaults, _originForErrors,
                "showtimes[" + std::to_string(i) + "]"));
        }
    }

    const boost::json::array* bookings =
        optionalArray(root, "bookings", _originForErrors, "bookings");
    if (bookings != nullptr) {
        for (std::size_t i = 0; i < bookings->size(); ++i) {
            snapshot.bookings.push_back(parseBooking(
                (*bookings)[i], _originForErrors, "bookings[" + std::to_string(i) + "]"));
        }
    }

    return snapshot;
}

std::string JsonCatalogStore::serialise(const CatalogSnapshot& _snapshot)
{
    boost::json::object root;

    boost::json::array movies;
    movies.reserve(_snapshot.movies.size());
    for (std::size_t i = 0; i < _snapshot.movies.size(); ++i) {
        const Movie& movie = _snapshot.movies[i];
        boost::json::object entry;
        entry["id"] = movie.id;
        entry["title"] = movie.title;
        entry["duration_minutes"] = movie.durationMinutes;
        entry["language"] = movie.language;
        entry["genre"] = movie.genre;
        movies.push_back(boost::json::value(std::move(entry)));
    }
    root["movies"] = std::move(movies);

    boost::json::array theaters;
    theaters.reserve(_snapshot.theaters.size());
    for (std::size_t i = 0; i < _snapshot.theaters.size(); ++i) {
        const Theater& theater = _snapshot.theaters[i];
        boost::json::object entry;
        entry["id"] = theater.id;
        entry["name"] = theater.name;
        entry["city"] = theater.city;
        entry["seat_capacity"] = theater.seatCapacity;
        entry["seats_per_row"] = theater.seatsPerRow;
        theaters.push_back(boost::json::value(std::move(entry)));
    }
    root["theaters"] = std::move(theaters);

    boost::json::array showtimes;
    showtimes.reserve(_snapshot.showtimes.size());
    for (std::size_t i = 0; i < _snapshot.showtimes.size(); ++i) {
        const ShowtimeSnapshot& entry = _snapshot.showtimes[i];
        boost::json::object object;
        object["id"] = entry.showtime.id;
        object["movie_id"] = entry.showtime.movieId;
        object["theater_id"] = entry.showtime.theaterId;
        object["start_time"] = schedule::formatTimeOfDay(entry.showtime.startTime);
        object["seat_capacity"] = entry.showtime.seatCapacity;
        object["seats_per_row"] = entry.showtime.seatsPerRow;
        object["booked_seats"] = toJsonArray(entry.bookedSeats);
        showtimes.push_back(boost::json::value(std::move(object)));
    }
    root["showtimes"] = std::move(showtimes);

    boost::json::array bookings;
    bookings.reserve(_snapshot.bookings.size());
    for (std::size_t i = 0; i < _snapshot.bookings.size(); ++i) {
        const Booking& booking = _snapshot.bookings[i];
        boost::json::object entry;
        entry["id"] = booking.id;
        entry["showtime_id"] = booking.showtimeId;
        entry["seats"] = toJsonArray(booking.seats);
        entry["customer_name"] = booking.customerName;
        entry["created_at"] = booking.createdAtEpochSeconds;
        bookings.push_back(boost::json::value(std::move(entry)));
    }
    root["bookings"] = std::move(bookings);

    std::ostringstream out;
    prettyPrint(out, boost::json::value(std::move(root)), 0);
    out << "\n";
    return out.str();
}

CatalogSnapshot JsonCatalogStore::load()
{
    // A missing catalog file means "start empty", not "fail to boot". That is
    // what makes a first run on a clean checkout work.
    std::error_code existsError;
    if (!std::filesystem::exists(m_path, existsError)) {
        MB_LOG_WARN("catalog file '{}' does not exist - starting with an empty catalog",
                    m_path);
        return CatalogSnapshot();
    }

    MB_LOG_INFO("loading catalog from '{}'", m_path);
    return parse(readWholeFile(m_path), m_defaults, m_path);
}

void JsonCatalogStore::save(const CatalogSnapshot& _snapshot)
{
    const std::string text = serialise(_snapshot);
    const std::string temporaryPath = m_path + ".tmp";

    // --- write to a temporary file first ---------------------------------
    {
        std::ofstream stream(temporaryPath.c_str(),
                             std::ios::out | std::ios::binary | std::ios::trunc);
        if (!stream.is_open()) {
            throw ServiceError(ErrorCode::PersistenceFailure,
                               "cannot open '" + temporaryPath + "' for writing");
        }

        stream << text;
        stream.flush();

        if (!stream.good()) {
            throw ServiceError(ErrorCode::PersistenceFailure,
                               "error while writing '" + temporaryPath + "'");
        }
    } // the stream is closed here, before the rename

    // --- then move it into place atomically ------------------------------
    //
    // std::filesystem::rename replaces the destination on POSIX. On Windows
    // it fails if the destination exists, so the old file is removed first.
    // That leaves a very small window with no catalog file, which is
    // acceptable: the file is a checkpoint, and the authoritative state is in
    // memory.
    std::error_code renameError;

#ifdef _WIN32
    std::error_code removeError;
    std::filesystem::remove(m_path, removeError);
#endif

    std::filesystem::rename(temporaryPath, m_path, renameError);

    if (renameError) {
        std::error_code cleanupError;
        std::filesystem::remove(temporaryPath, cleanupError);
        throw ServiceError(ErrorCode::PersistenceFailure,
                           "cannot move '" + temporaryPath + "' onto '" + m_path
                               + "': " + renameError.message());
    }

    MB_LOG_DEBUG("catalog saved to '{}' ({} bytes)", m_path, text.size());
}

} // namespace moviebackend
