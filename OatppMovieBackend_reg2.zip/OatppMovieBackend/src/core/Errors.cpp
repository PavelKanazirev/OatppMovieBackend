/**
 * @file Errors.cpp
 * @brief Implementation of the error taxonomy helpers.
 */
#include "moviebackend/Errors.hpp"

namespace moviebackend {

const char* toString(ErrorCode _code) noexcept
{
    // A plain switch with no default: if somebody adds an ErrorCode later,
    // the compiler warns about the unhandled case instead of silently
    // returning "UNKNOWN" at run time. That is the whole reason there is no
    // default label here.
    switch (_code) {
        case ErrorCode::NotFound:           return "NOT_FOUND";
        case ErrorCode::InvalidArgument:    return "INVALID_ARGUMENT";
        case ErrorCode::Conflict:           return "CONFLICT";
        case ErrorCode::SeatUnavailable:    return "SEAT_UNAVAILABLE";
        case ErrorCode::PersistenceFailure: return "PERSISTENCE_FAILURE";
        case ErrorCode::Internal:           return "INTERNAL";
    }
    return "INTERNAL";
}

ServiceError notFound(const std::string& _entity, const std::string& _id)
{
    return ServiceError(ErrorCode::NotFound,
                        "no such " + _entity + ": '" + _id + "'");
}

ServiceError invalidArgument(const std::string& _message)
{
    return ServiceError(ErrorCode::InvalidArgument, _message);
}

ServiceError conflict(const std::string& _message)
{
    return ServiceError(ErrorCode::Conflict, _message);
}

} // namespace moviebackend
