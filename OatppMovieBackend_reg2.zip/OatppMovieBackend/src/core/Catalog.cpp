/**
 * @file Catalog.cpp
 * @brief Implementation of the in-memory catalog.
 *
 * Read the long comment at the top of Catalog.hpp first - it explains the
 * locking strategy that every method here follows.
 *
 * The shape of every public method in this file is the same:
 *
 *     ReturnType Catalog::something(args)
 *     {
 *         ReturnType result;
 *         {
 *             std::lock_guard<std::mutex> guard(m_mutex);   // CRITICAL SECTION
 *             ... work entirely on member state ...
 *         }                                                 // lock released
 *         notifyChanged();   // mutators only, and always outside the lock
 *         return result;
 *     }
 *
 * Deviating from that shape is how this file would acquire a deadlock, so it
 * is worth keeping mechanical.
 */
#include "moviebackend/Catalog.hpp"

#include "moviebackend/Errors.hpp"
#include "moviebackend/Logging.hpp"
#include "moviebackend/Schedule.hpp"

#include <chrono>
#include <set>
#include <utility>

namespace moviebackend {

namespace {

/** @return the current wall-clock time as seconds since the Unix epoch. */
std::int64_t nowEpochSeconds()
{
    const std::chrono::system_clock::time_point now =
        std::chrono::system_clock::now();
    return std::chrono::duration_cast<std::chrono::seconds>(
               now.time_since_epoch())
        .count();
}

/**
 * @brief Apply the configured defaults to a theater that left them at 0.
 *
 * "0 means default" is the convention used by the admin API so that a caller
 * can omit the field entirely and get the required capacity of 20.
 */
Theater withDefaults(const Theater& _theater, const TheaterDefaults& _defaults)
{
    Theater result = _theater;
    if (result.seatCapacity <= 0) {
        result.seatCapacity = _defaults.seatCapacity;
    }
    if (result.seatsPerRow <= 0) {
        result.seatsPerRow = _defaults.seatsPerRow;
    }
    return result;
}

} // unnamed namespace

/* =========================================================================
 * Construction
 * ========================================================================= */

Catalog::Catalog(const TheaterDefaults& _defaults)
    : m_defaults(_defaults)
    , m_movieIds("m")
    , m_theaterIds("t")
    , m_showtimeIds("s")
    , m_bookingIds("b")
{
    // Probe the configured defaults immediately. Without this, a config file
    // saying `seat_capacity: 1000, seats_per_row: 10` (100 rows, more than the
    // 26 we can label) is accepted here and then fails much later - at the
    // first theater creation, or during catalog load with a message blaming
    // catalog.json rather than the config field that is actually wrong.
    try {
        const SeatMap probe(m_defaults.seatCapacity, m_defaults.seatsPerRow);
        (void)probe;
    } catch (const ServiceError& error) {
        throw invalidArgument(std::string("theater_defaults in the configuration "
                                          "are not a usable seat layout: ")
                              + error.what());
    }
}

Catalog::~Catalog() = default;

void Catalog::setChangeListener(CatalogChangeListener* _listener)
{
    // CRITICAL SECTION: m_listenerMutex only. Kept separate from m_mutex so
    // that attaching or detaching an observer never blocks a booking.
    std::unique_lock<std::mutex> lock(m_listenerMutex);

    m_listener = _listener;

    // Then wait for any callback that was already running to finish.
    //
    // Publishing the new pointer first is what makes this terminate: a
    // notifyChanged() that has not yet read m_listener will now read the new
    // value, so only the already-started callbacks are left to drain.
    //
    // Without this wait, ~PersistenceWorker could detach and then destroy
    // itself while a request thread was still inside its onCatalogChanged() -
    // a use-after-free that would reproduce roughly never in testing.
    m_listenerIdle.wait(lock, [this]() { return m_activeNotifications == 0; });
}

void Catalog::notifyChanged() noexcept
{
    CatalogChangeListener* listener = nullptr;
    {
        const std::lock_guard<std::mutex> guard(m_listenerMutex);
        listener = m_listener;
        if (listener == nullptr) {
            return;
        }
        // Announce the in-flight callback before releasing the lock, so a
        // concurrent detach cannot slip past it.
        ++m_activeNotifications;
    }

    // The callback runs with NO lock held - see the header. onCatalogChanged
    // is declared noexcept, so there is nothing to catch here.
    listener->onCatalogChanged();

    {
        const std::lock_guard<std::mutex> guard(m_listenerMutex);
        --m_activeNotifications;
    }
    m_listenerIdle.notify_all();
}

/* =========================================================================
 * Private helpers - the caller must already hold m_mutex
 * ========================================================================= */

const Movie& Catalog::requireMovieLocked(const MovieId& _id) const
{
    const std::map<MovieId, Movie>::const_iterator it = m_movies.find(_id);
    if (it == m_movies.end()) {
        throw notFound("movie", _id);
    }
    return it->second;
}

const Theater& Catalog::requireTheaterLocked(const TheaterId& _id) const
{
    const std::map<TheaterId, Theater>::const_iterator it = m_theaters.find(_id);
    if (it == m_theaters.end()) {
        throw notFound("theater", _id);
    }
    return it->second;
}

const Catalog::ShowtimeRecord& Catalog::requireShowtimeLocked(
    const ShowtimeId& _id) const
{
    const std::map<ShowtimeId, ShowtimeRecord>::const_iterator it =
        m_showtimes.find(_id);
    if (it == m_showtimes.end()) {
        throw notFound("showtime", _id);
    }
    return it->second;
}

Catalog::ShowtimeRecord& Catalog::requireShowtimeLocked(const ShowtimeId& _id)
{
    const std::map<ShowtimeId, ShowtimeRecord>::iterator it = m_showtimes.find(_id);
    if (it == m_showtimes.end()) {
        throw notFound("showtime", _id);
    }
    return it->second;
}

void Catalog::eraseShowtimeLocked(const ShowtimeId& _id)
{
    // Bookings belong to a showtime; removing the screening removes them.
    std::map<BookingId, Booking>::iterator it = m_bookings.begin();
    while (it != m_bookings.end()) {
        if (it->second.showtimeId == _id) {
            it = m_bookings.erase(it);
        } else {
            ++it;
        }
    }
    m_showtimes.erase(_id);
}

/* =========================================================================
 * Bulk load / snapshot
 * ========================================================================= */

CatalogSnapshot Catalog::validateSnapshot(const CatalogSnapshot& _snapshot,
                                          const TheaterDefaults& _defaults)
{
    // Build the validated copy to one side. Nothing is installed unless this
    // whole function succeeds, which is what gives restore() its all-or-
    // nothing behaviour.
    CatalogSnapshot validated;

    std::set<MovieId>   movieIds;
    std::set<TheaterId> theaterIds;

    for (std::size_t i = 0; i < _snapshot.movies.size(); ++i) {
        const Movie& movie = _snapshot.movies[i];
        if (movie.id.empty()) {
            throw invalidArgument("catalog contains a movie with an empty id");
        }
        if (movie.durationMinutes <= 0) {
            throw invalidArgument("movie '" + movie.id
                                  + "' has a non-positive duration");
        }
        if (!movieIds.insert(movie.id).second) {
            throw invalidArgument("duplicate movie id '" + movie.id + "'");
        }
        validated.movies.push_back(movie);
    }

    for (std::size_t i = 0; i < _snapshot.theaters.size(); ++i) {
        const Theater theater = withDefaults(_snapshot.theaters[i], _defaults);
        if (theater.id.empty()) {
            throw invalidArgument("catalog contains a theater with an empty id");
        }
        if (!theaterIds.insert(theater.id).second) {
            throw invalidArgument("duplicate theater id '" + theater.id + "'");
        }
        // Constructing a SeatMap validates the layout and throws if the
        // capacity cannot be labelled.
        const SeatMap probe(theater.seatCapacity, theater.seatsPerRow);
        (void)probe;
        validated.theaters.push_back(theater);
    }

    std::set<ShowtimeId> showtimeIds;

    // Keeps the showtime entries reachable while the bookings below are
    // cross-checked against them.
    std::map<ShowtimeId, ShowtimeSnapshot> showtimesById;

    // (theaterId, startTime) pairs, to catch two screenings in one hall at
    // exactly the same minute.
    std::set<std::pair<TheaterId, MinutesSinceMidnight> > occupiedSlots;

    for (std::size_t i = 0; i < _snapshot.showtimes.size(); ++i) {
        const ShowtimeSnapshot& entry = _snapshot.showtimes[i];
        const Showtime& showtime = entry.showtime;

        if (showtime.id.empty()) {
            throw invalidArgument("catalog contains a showtime with an empty id");
        }
        if (!showtimeIds.insert(showtime.id).second) {
            throw invalidArgument("duplicate showtime id '" + showtime.id + "'");
        }
        if (movieIds.find(showtime.movieId) == movieIds.end()) {
            throw invalidArgument("showtime '" + showtime.id
                                  + "' refers to unknown movie '"
                                  + showtime.movieId + "'");
        }
        if (theaterIds.find(showtime.theaterId) == theaterIds.end()) {
            throw invalidArgument("showtime '" + showtime.id
                                  + "' refers to unknown theater '"
                                  + showtime.theaterId + "'");
        }
        if (showtime.startTime < 0 || showtime.startTime >= 24 * 60) {
            throw invalidArgument("showtime '" + showtime.id
                                  + "' has a start time outside the day");
        }

        const std::pair<TheaterId, MinutesSinceMidnight> slot(
            showtime.theaterId, showtime.startTime);
        if (!occupiedSlots.insert(slot).second) {
            throw invalidArgument("theater '" + showtime.theaterId
                                  + "' has two showtimes starting at "
                                  + schedule::formatTimeOfDay(showtime.startTime));
        }

        // Every booked seat must be a real seat in this showtime's layout.
        SeatMap seats(showtime.seatCapacity, showtime.seatsPerRow);
        for (std::size_t s = 0; s < entry.bookedSeats.size(); ++s) {
            // book() throws SeatUnavailable on a duplicate, which is exactly
            // the validation we want for a file listing "a1" twice.
            seats.book(entry.bookedSeats[s]);
        }

        validated.showtimes.push_back(entry);
        showtimesById.insert(std::make_pair(showtime.id, entry));
    }

    std::set<BookingId> bookingIds;

    // (showtimeId, seatLabel) pairs already claimed by some booking. This is
    // what stops two bookings in the file from owning the same seat.
    std::set<std::pair<ShowtimeId, SeatLabel> > claimedSeats;

    for (std::size_t i = 0; i < _snapshot.bookings.size(); ++i) {
        const Booking& booking = _snapshot.bookings[i];
        if (booking.id.empty()) {
            throw invalidArgument("catalog contains a booking with an empty id");
        }
        if (!bookingIds.insert(booking.id).second) {
            throw invalidArgument("duplicate booking id '" + booking.id + "'");
        }

        const std::map<ShowtimeId, ShowtimeSnapshot>::const_iterator showtimeIt =
            showtimesById.find(booking.showtimeId);
        if (showtimeIt == showtimesById.end()) {
            throw invalidArgument("booking '" + booking.id
                                  + "' refers to unknown showtime '"
                                  + booking.showtimeId + "'");
        }
        if (booking.seats.empty()) {
            throw invalidArgument("booking '" + booking.id + "' reserves no seats");
        }

        // The seat map and the booking ledger are two views of the same fact
        // and must agree. Loading a file where they disagree would reintroduce
        // exactly the bug this service exists to prevent: two bookings holding
        // seat "a1", where cancelling one frees a seat the other still owns.
        //
        // Note the check is one-directional. A showtime may legitimately mark
        // a seat booked with no booking record behind it (the seed catalog
        // does this to represent a pre-sold house); what is forbidden is a
        // booking claiming a seat that is not marked, or claimed twice.
        SeatMap layout(showtimeIt->second.showtime.seatCapacity,
                       showtimeIt->second.showtime.seatsPerRow);

        std::set<SeatLabel> markedBooked;
        for (std::size_t s = 0; s < showtimeIt->second.bookedSeats.size(); ++s) {
            markedBooked.insert(showtimeIt->second.bookedSeats[s]);
        }

        for (std::size_t s = 0; s < booking.seats.size(); ++s) {
            const SeatLabel& seat = booking.seats[s];

            const std::optional<std::size_t> index = layout.labelToIndex(seat);
            if (!index.has_value()) {
                throw invalidArgument("booking '" + booking.id + "' claims seat '"
                                      + seat + "', which does not exist in showtime '"
                                      + booking.showtimeId + "'");
            }

            // Compare canonical labels, so "A1" and "a1" cannot slip past as
            // two different seats.
            const SeatLabel canonical = layout.indexToLabel(*index);

            if (markedBooked.find(canonical) == markedBooked.end()
                && markedBooked.find(seat) == markedBooked.end()) {
                throw invalidArgument("booking '" + booking.id + "' claims seat '"
                                      + seat + "' but showtime '" + booking.showtimeId
                                      + "' does not list it as booked");
            }

            const std::pair<ShowtimeId, SeatLabel> claim(booking.showtimeId, canonical);
            if (!claimedSeats.insert(claim).second) {
                throw invalidArgument("seat '" + seat + "' in showtime '"
                                      + booking.showtimeId
                                      + "' is claimed by more than one booking");
            }
        }

        validated.bookings.push_back(booking);
    }

    return validated;
}

void Catalog::restore(const CatalogSnapshot& _snapshot)
{
    // Validate *before* taking the lock. Validation is pure and can be slow;
    // there is no reason to block bookings while it runs, and if it throws
    // the catalog was never touched.
    const CatalogSnapshot validated = validateSnapshot(_snapshot, m_defaults);

    {
        // CRITICAL SECTION: swap the entire world in one go, so no request
        // thread can ever observe a half-loaded catalog.
        const std::lock_guard<std::mutex> guard(m_mutex);

        m_movies.clear();
        m_theaters.clear();
        m_showtimes.clear();
        m_bookings.clear();

        for (std::size_t i = 0; i < validated.movies.size(); ++i) {
            m_movies.insert(std::make_pair(validated.movies[i].id,
                                           validated.movies[i]));
            m_movieIds.observeExistingId(validated.movies[i].id);
        }

        for (std::size_t i = 0; i < validated.theaters.size(); ++i) {
            m_theaters.insert(std::make_pair(validated.theaters[i].id,
                                             validated.theaters[i]));
            m_theaterIds.observeExistingId(validated.theaters[i].id);
        }

        for (std::size_t i = 0; i < validated.showtimes.size(); ++i) {
            const ShowtimeSnapshot& entry = validated.showtimes[i];

            SeatMap seats(entry.showtime.seatCapacity, entry.showtime.seatsPerRow);
            for (std::size_t s = 0; s < entry.bookedSeats.size(); ++s) {
                seats.book(entry.bookedSeats[s]);
            }

            m_showtimes.insert(std::make_pair(
                entry.showtime.id, ShowtimeRecord(entry.showtime, seats)));
            m_showtimeIds.observeExistingId(entry.showtime.id);
        }

        for (std::size_t i = 0; i < validated.bookings.size(); ++i) {
            m_bookings.insert(std::make_pair(validated.bookings[i].id,
                                             validated.bookings[i]));
            m_bookingIds.observeExistingId(validated.bookings[i].id);
        }
    }

    MB_LOG_INFO("catalog restored: {} movies, {} theaters, {} showtimes, {} bookings",
                validated.movies.size(), validated.theaters.size(),
                validated.showtimes.size(), validated.bookings.size());

    // restore() is itself a change, so the persistence worker is told - which
    // is harmless when the change came from the store in the first place
    // (it just rewrites an identical file once).
    notifyChanged();
}

CatalogSnapshot Catalog::snapshot() const
{
    CatalogSnapshot result;

    // CRITICAL SECTION: the longest one in the system - a copy of every
    // container. Still only memory traffic; no I/O happens under the lock.
    const std::lock_guard<std::mutex> guard(m_mutex);

    result.movies.reserve(m_movies.size());
    for (std::map<MovieId, Movie>::const_iterator it = m_movies.begin();
         it != m_movies.end(); ++it) {
        result.movies.push_back(it->second);
    }

    result.theaters.reserve(m_theaters.size());
    for (std::map<TheaterId, Theater>::const_iterator it = m_theaters.begin();
         it != m_theaters.end(); ++it) {
        result.theaters.push_back(it->second);
    }

    result.showtimes.reserve(m_showtimes.size());
    for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
         it != m_showtimes.end(); ++it) {
        ShowtimeSnapshot entry;
        entry.showtime = it->second.showtime;
        entry.bookedSeats = it->second.seats.bookedSeats();
        result.showtimes.push_back(entry);
    }

    result.bookings.reserve(m_bookings.size());
    for (std::map<BookingId, Booking>::const_iterator it = m_bookings.begin();
         it != m_bookings.end(); ++it) {
        result.bookings.push_back(it->second);
    }

    return result;
}

/* =========================================================================
 * Queries
 * ========================================================================= */

std::vector<Movie> Catalog::listPlayingMovies() const
{
    std::vector<Movie> result;

    const std::lock_guard<std::mutex> guard(m_mutex);

    // "Playing" = has at least one showtime. Collect the ids that appear in
    // the showtime map, then emit those movies in id order (std::map already
    // iterates sorted, so the output is deterministic - which the smoke tests
    // depend on).
    std::set<MovieId> playing;
    for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
         it != m_showtimes.end(); ++it) {
        playing.insert(it->second.showtime.movieId);
    }

    for (std::map<MovieId, Movie>::const_iterator it = m_movies.begin();
         it != m_movies.end(); ++it) {
        if (playing.find(it->first) != playing.end()) {
            result.push_back(it->second);
        }
    }
    return result;
}

std::vector<Movie> Catalog::listAllMovies() const
{
    std::vector<Movie> result;

    const std::lock_guard<std::mutex> guard(m_mutex);

    result.reserve(m_movies.size());
    for (std::map<MovieId, Movie>::const_iterator it = m_movies.begin();
         it != m_movies.end(); ++it) {
        result.push_back(it->second);
    }
    return result;
}

std::vector<Theater> Catalog::listTheaters() const
{
    std::vector<Theater> result;

    const std::lock_guard<std::mutex> guard(m_mutex);

    result.reserve(m_theaters.size());
    for (std::map<TheaterId, Theater>::const_iterator it = m_theaters.begin();
         it != m_theaters.end(); ++it) {
        result.push_back(it->second);
    }
    return result;
}

Movie Catalog::getMovie(const MovieId& _movieId) const
{
    const std::lock_guard<std::mutex> guard(m_mutex);
    return requireMovieLocked(_movieId);   // returns a copy
}

Theater Catalog::getTheater(const TheaterId& _theaterId) const
{
    const std::lock_guard<std::mutex> guard(m_mutex);
    return requireTheaterLocked(_theaterId);
}

Showtime Catalog::getShowtime(const ShowtimeId& _showtimeId) const
{
    const std::lock_guard<std::mutex> guard(m_mutex);
    return requireShowtimeLocked(_showtimeId).showtime;
}

std::vector<Theater> Catalog::listTheatersShowingMovie(const MovieId& _movieId) const
{
    std::vector<Theater> result;

    const std::lock_guard<std::mutex> guard(m_mutex);

    // Asking about a movie that does not exist is a 404, not an empty list -
    // the client should be able to tell "no such film" from "not on anywhere".
    requireMovieLocked(_movieId);

    std::set<TheaterId> theaterIds;
    for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
         it != m_showtimes.end(); ++it) {
        if (it->second.showtime.movieId == _movieId) {
            theaterIds.insert(it->second.showtime.theaterId);
        }
    }

    for (std::map<TheaterId, Theater>::const_iterator it = m_theaters.begin();
         it != m_theaters.end(); ++it) {
        if (theaterIds.find(it->first) != theaterIds.end()) {
            result.push_back(it->second);
        }
    }
    return result;
}

std::vector<Showtime> Catalog::listShowtimes(const MovieId& _movieId,
                                             const TheaterId& _theaterId) const
{
    std::vector<Showtime> result;

    const std::lock_guard<std::mutex> guard(m_mutex);

    requireMovieLocked(_movieId);
    requireTheaterLocked(_theaterId);

    for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
         it != m_showtimes.end(); ++it) {
        if (it->second.showtime.movieId == _movieId
            && it->second.showtime.theaterId == _theaterId) {
            result.push_back(it->second.showtime);
        }
    }

    // Sorted by start time - a timeline is only useful in order. Written as a
    // plain insertion into a sorted position rather than std::sort with a
    // comparator lambda, in keeping with the project's style.
    for (std::size_t i = 1; i < result.size(); ++i) {
        const Showtime key = result[i];
        std::size_t j = i;
        while (j > 0 && result[j - 1].startTime > key.startTime) {
            result[j] = result[j - 1];
            --j;
        }
        result[j] = key;
    }

    return result;
}

std::vector<Showtime> Catalog::listAllShowtimes() const
{
    std::vector<Showtime> result;

    const std::lock_guard<std::mutex> guard(m_mutex);

    result.reserve(m_showtimes.size());
    for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
         it != m_showtimes.end(); ++it) {
        result.push_back(it->second.showtime);
    }
    return result;
}

std::vector<SeatLabel> Catalog::listAvailableSeats(const ShowtimeId& _showtimeId) const
{
    const std::lock_guard<std::mutex> guard(m_mutex);
    return requireShowtimeLocked(_showtimeId).seats.availableSeats();
}

std::vector<SeatLabel> Catalog::listBookedSeats(const ShowtimeId& _showtimeId) const
{
    const std::lock_guard<std::mutex> guard(m_mutex);
    return requireShowtimeLocked(_showtimeId).seats.bookedSeats();
}

/* =========================================================================
 * Booking - the over-booking guard
 * ========================================================================= */

Booking Catalog::bookSeats(const ShowtimeId& _showtimeId,
                           const std::vector<SeatLabel>& _seats,
                           const std::string& _customerName)
{
    if (_seats.empty()) {
        throw invalidArgument("a booking must reserve at least one seat");
    }

    Booking booking;

    {
        /* -----------------------------------------------------------------
         * CRITICAL SECTION - the whole point of the exercise.
         *
         * Check and act happen without releasing the lock in between, so two
         * threads asking for the same seat cannot both pass the check. The
         * loser sees the seat already marked Booked and gets SeatUnavailable.
         * ----------------------------------------------------------------- */
        const std::lock_guard<std::mutex> guard(m_mutex);

        ShowtimeRecord& record = requireShowtimeLocked(_showtimeId);

        // --- Phase 1: validate every seat before changing anything ---------
        //
        // Doing all the checking first means the mutation phase below cannot
        // fail halfway through and leave a partially applied booking.

        std::set<SeatLabel> requested;
        for (std::size_t i = 0; i < _seats.size(); ++i) {
            const SeatLabel& label = _seats[i];

            const std::optional<std::size_t> index =
                record.seats.labelToIndex(label);
            if (!index.has_value()) {
                throw notFound("seat", label);
            }

            // Reject "a1" twice in one request: it is almost certainly a
            // client bug, and silently collapsing it would make the seat
            // count in the response disagree with the request.
            if (!requested.insert(record.seats.indexToLabel(*index)).second) {
                throw invalidArgument("seat '" + label
                                      + "' appears more than once in the request");
            }

            if (!record.seats.isFree(label)) {
                throw ServiceError(ErrorCode::SeatUnavailable,
                                   "seat '" + label + "' is already booked");
            }
        }

        // --- Phase 2: commit ----------------------------------------------
        //
        // Every seat was verified free a few lines ago and the lock has not
        // been released, so none of these calls can throw.

        booking.id = m_bookingIds.next();
        booking.showtimeId = _showtimeId;
        booking.customerName = _customerName;
        booking.createdAtEpochSeconds = nowEpochSeconds();

        for (std::set<SeatLabel>::const_iterator it = requested.begin();
             it != requested.end(); ++it) {
            record.seats.book(*it);
            booking.seats.push_back(*it);
        }

        m_bookings.insert(std::make_pair(booking.id, booking));
    }
    // ---- lock released ---------------------------------------------------

    MB_LOG_INFO("booking {} confirmed: {} seat(s) for showtime {}",
                booking.id, booking.seats.size(), _showtimeId);

    notifyChanged();
    return booking;
}

Booking Catalog::getBooking(const BookingId& _bookingId) const
{
    const std::lock_guard<std::mutex> guard(m_mutex);

    const std::map<BookingId, Booking>::const_iterator it = m_bookings.find(_bookingId);
    if (it == m_bookings.end()) {
        throw notFound("booking", _bookingId);
    }
    return it->second;
}

std::vector<Booking> Catalog::listBookings() const
{
    std::vector<Booking> result;

    const std::lock_guard<std::mutex> guard(m_mutex);

    result.reserve(m_bookings.size());
    for (std::map<BookingId, Booking>::const_iterator it = m_bookings.begin();
         it != m_bookings.end(); ++it) {
        result.push_back(it->second);
    }
    return result;
}

void Catalog::cancelBooking(const BookingId& _bookingId)
{
    {
        // CRITICAL SECTION: freeing the seats and dropping the booking record
        // must be one indivisible step, or a seat could be double-freed.
        const std::lock_guard<std::mutex> guard(m_mutex);

        const std::map<BookingId, Booking>::iterator it = m_bookings.find(_bookingId);
        if (it == m_bookings.end()) {
            throw notFound("booking", _bookingId);
        }

        const std::map<ShowtimeId, ShowtimeRecord>::iterator showtimeIt =
            m_showtimes.find(it->second.showtimeId);

        if (showtimeIt != m_showtimes.end()) {
            for (std::size_t i = 0; i < it->second.seats.size(); ++i) {
                const SeatLabel& seat = it->second.seats[i];

                // Skip anything that is not a seat of this showtime instead of
                // letting release() throw. A throw here would abandon the
                // cancellation half-done - some seats freed, the booking record
                // still present and now permanently uncancellable. The seats a
                // booking holds are validated on load and on creation, so this
                // can only trigger on state that got past validation; degrading
                // to "free what we can" is strictly better than corrupting.
                if (showtimeIt->second.seats.labelToIndex(seat).has_value()) {
                    showtimeIt->second.seats.release(seat);
                } else {
                    MB_LOG_WARN("booking {} holds seat '{}', which is not part of "
                                "showtime {} - ignoring it while cancelling",
                                _bookingId, seat, it->second.showtimeId);
                }
            }
        }

        m_bookings.erase(it);
    }

    MB_LOG_INFO("booking {} cancelled", _bookingId);
    notifyChanged();
}

/* =========================================================================
 * Administration - movies
 * ========================================================================= */

Movie Catalog::addMovie(const Movie& _movie)
{
    if (_movie.title.empty()) {
        throw invalidArgument("movie title must not be empty");
    }
    if (_movie.durationMinutes <= 0) {
        throw invalidArgument("movie duration must be positive");
    }

    Movie stored = _movie;

    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        if (stored.id.empty()) {
            stored.id = m_movieIds.next();
        } else if (m_movies.find(stored.id) != m_movies.end()) {
            throw conflict("movie id '" + stored.id + "' already exists");
        } else {
            m_movieIds.observeExistingId(stored.id);
        }

        m_movies.insert(std::make_pair(stored.id, stored));
    }

    MB_LOG_INFO("movie {} added: '{}'", stored.id, stored.title);
    notifyChanged();
    return stored;
}

Movie Catalog::updateMovie(const MovieId& _movieId, const Movie& _changes)
{
    if (_changes.title.empty()) {
        throw invalidArgument("movie title must not be empty");
    }
    if (_changes.durationMinutes <= 0) {
        throw invalidArgument("movie duration must be positive");
    }

    Movie stored;

    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        const std::map<MovieId, Movie>::iterator it = m_movies.find(_movieId);
        if (it == m_movies.end()) {
            throw notFound("movie", _movieId);
        }

        // The id is immutable - changing it would orphan every showtime that
        // points at it. Everything else is replaced wholesale.
        it->second.title = _changes.title;
        it->second.durationMinutes = _changes.durationMinutes;
        it->second.language = _changes.language;
        it->second.genre = _changes.genre;

        stored = it->second;
    }

    MB_LOG_INFO("movie {} updated", _movieId);
    notifyChanged();
    return stored;
}

void Catalog::removeMovie(const MovieId& _movieId)
{
    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        if (m_movies.find(_movieId) == m_movies.end()) {
            throw notFound("movie", _movieId);
        }

        // Collect first, erase second: erasing from m_showtimes while
        // iterating it would invalidate the iterator.
        std::vector<ShowtimeId> doomed;
        for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
             it != m_showtimes.end(); ++it) {
            if (it->second.showtime.movieId == _movieId) {
                doomed.push_back(it->first);
            }
        }
        for (std::size_t i = 0; i < doomed.size(); ++i) {
            eraseShowtimeLocked(doomed[i]);
        }

        m_movies.erase(_movieId);
    }

    MB_LOG_INFO("movie {} removed", _movieId);
    notifyChanged();
}

/* =========================================================================
 * Administration - theaters
 * ========================================================================= */

Theater Catalog::addTheater(const Theater& _theater)
{
    if (_theater.name.empty()) {
        throw invalidArgument("theater name must not be empty");
    }

    Theater stored = withDefaults(_theater, m_defaults);

    // Validating the layout outside the lock keeps the critical section free
    // of anything that can throw for a reason unrelated to shared state.
    const SeatMap probe(stored.seatCapacity, stored.seatsPerRow);
    (void)probe;

    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        if (stored.id.empty()) {
            stored.id = m_theaterIds.next();
        } else if (m_theaters.find(stored.id) != m_theaters.end()) {
            throw conflict("theater id '" + stored.id + "' already exists");
        } else {
            m_theaterIds.observeExistingId(stored.id);
        }

        m_theaters.insert(std::make_pair(stored.id, stored));
    }

    MB_LOG_INFO("theater {} added: '{}' ({} seats)",
                stored.id, stored.name, stored.seatCapacity);
    notifyChanged();
    return stored;
}

Theater Catalog::updateTheater(const TheaterId& _theaterId, const Theater& _changes)
{
    if (_changes.name.empty()) {
        throw invalidArgument("theater name must not be empty");
    }

    Theater stored;

    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        const std::map<TheaterId, Theater>::iterator it = m_theaters.find(_theaterId);
        if (it == m_theaters.end()) {
            throw notFound("theater", _theaterId);
        }

        Theater updated = it->second;
        updated.name = _changes.name;
        updated.city = _changes.city;
        if (_changes.seatCapacity > 0) {
            updated.seatCapacity = _changes.seatCapacity;
        }
        if (_changes.seatsPerRow > 0) {
            updated.seatsPerRow = _changes.seatsPerRow;
        }

        const bool layoutChanged =
            updated.seatCapacity != it->second.seatCapacity
            || updated.seatsPerRow != it->second.seatsPerRow;

        if (layoutChanged) {
            // Re-lay-out every screening of this theater. Build all of the new
            // seat maps to one side first: if any of them refuses (because a
            // booked seat would vanish) we throw before touching live state,
            // so the update is all-or-nothing.
            std::vector<std::pair<ShowtimeId, SeatMap> > relaidOut;

            for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator sIt = m_showtimes.begin();
                 sIt != m_showtimes.end(); ++sIt) {
                if (sIt->second.showtime.theaterId != _theaterId) {
                    continue;
                }
                SeatMap candidate = sIt->second.seats;
                candidate.relayout(updated.seatCapacity, updated.seatsPerRow);
                relaidOut.push_back(std::make_pair(sIt->first, candidate));
            }

            // Nothing threw - commit.
            for (std::size_t i = 0; i < relaidOut.size(); ++i) {
                ShowtimeRecord& record = m_showtimes.at(relaidOut[i].first);
                record.seats = relaidOut[i].second;
                record.showtime.seatCapacity = updated.seatCapacity;
                record.showtime.seatsPerRow = updated.seatsPerRow;
            }
        }

        it->second = updated;
        stored = updated;
    }

    MB_LOG_INFO("theater {} updated", _theaterId);
    notifyChanged();
    return stored;
}

void Catalog::removeTheater(const TheaterId& _theaterId)
{
    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        if (m_theaters.find(_theaterId) == m_theaters.end()) {
            throw notFound("theater", _theaterId);
        }

        std::vector<ShowtimeId> doomed;
        for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
             it != m_showtimes.end(); ++it) {
            if (it->second.showtime.theaterId == _theaterId) {
                doomed.push_back(it->first);
            }
        }
        for (std::size_t i = 0; i < doomed.size(); ++i) {
            eraseShowtimeLocked(doomed[i]);
        }

        m_theaters.erase(_theaterId);
    }

    MB_LOG_INFO("theater {} removed", _theaterId);
    notifyChanged();
}

/* =========================================================================
 * Administration - showtimes
 * ========================================================================= */

Showtime Catalog::addShowtime(const Showtime& _showtime)
{
    Showtime stored;

    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        requireMovieLocked(_showtime.movieId);
        const Theater& theater = requireTheaterLocked(_showtime.theaterId);

        if (_showtime.startTime < 0 || _showtime.startTime >= 24 * 60) {
            throw invalidArgument("showtime start time is outside the day");
        }

        // One hall cannot run two films at the same minute.
        for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
             it != m_showtimes.end(); ++it) {
            if (it->second.showtime.theaterId == _showtime.theaterId
                && it->second.showtime.startTime == _showtime.startTime) {
                throw conflict("theater '" + _showtime.theaterId
                               + "' already has a showtime at "
                               + schedule::formatTimeOfDay(_showtime.startTime));
            }
        }

        stored = _showtime;
        // The seat layout always comes from the theater, never from the
        // request - that keeps a hall's screenings consistent with each other.
        stored.seatCapacity = theater.seatCapacity;
        stored.seatsPerRow = theater.seatsPerRow;

        if (stored.id.empty()) {
            stored.id = m_showtimeIds.next();
        } else if (m_showtimes.find(stored.id) != m_showtimes.end()) {
            throw conflict("showtime id '" + stored.id + "' already exists");
        } else {
            m_showtimeIds.observeExistingId(stored.id);
        }

        const SeatMap seats(stored.seatCapacity, stored.seatsPerRow);
        m_showtimes.insert(std::make_pair(stored.id, ShowtimeRecord(stored, seats)));
    }

    MB_LOG_INFO("showtime {} added: movie {} in theater {} at {}",
                stored.id, stored.movieId, stored.theaterId,
                schedule::formatTimeOfDay(stored.startTime));
    notifyChanged();
    return stored;
}

Showtime Catalog::updateShowtimeStart(const ShowtimeId& _showtimeId,
                                      MinutesSinceMidnight _newStartTime)
{
    if (_newStartTime < 0 || _newStartTime >= 24 * 60) {
        throw invalidArgument("showtime start time is outside the day");
    }

    Showtime stored;

    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        ShowtimeRecord& record = requireShowtimeLocked(_showtimeId);

        for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
             it != m_showtimes.end(); ++it) {
            if (it->first != _showtimeId
                && it->second.showtime.theaterId == record.showtime.theaterId
                && it->second.showtime.startTime == _newStartTime) {
                throw conflict("theater '" + record.showtime.theaterId
                               + "' already has a showtime at "
                               + schedule::formatTimeOfDay(_newStartTime));
            }
        }

        // Bookings are intentionally kept: the audience keeps its seats, the
        // screening simply moves.
        record.showtime.startTime = _newStartTime;
        stored = record.showtime;
    }

    MB_LOG_INFO("showtime {} moved to {}",
                _showtimeId, schedule::formatTimeOfDay(_newStartTime));
    notifyChanged();
    return stored;
}

void Catalog::removeShowtime(const ShowtimeId& _showtimeId)
{
    {
        const std::lock_guard<std::mutex> guard(m_mutex);

        if (m_showtimes.find(_showtimeId) == m_showtimes.end()) {
            throw notFound("showtime", _showtimeId);
        }
        eraseShowtimeLocked(_showtimeId);
    }

    MB_LOG_INFO("showtime {} removed", _showtimeId);
    notifyChanged();
}

std::vector<Showtime> Catalog::applyDefaultSchedule(const MovieId& _movieId,
                                                    const TheaterId& _theaterId,
                                                    const ScheduleConfig& _config)
{
    std::vector<Showtime> created;

    {
        // CRITICAL SECTION: replacing a whole timeline must be atomic, or a
        // client could see the old screenings deleted and the new ones not
        // yet present.
        const std::lock_guard<std::mutex> guard(m_mutex);

        const Movie& movie = requireMovieLocked(_movieId);
        const Theater& theater = requireTheaterLocked(_theaterId);

        const std::vector<MinutesSinceMidnight> startTimes =
            schedule::generateDefaultStartTimes(movie.durationMinutes, _config);

        // Drop the existing timeline for this pair, bookings included.
        std::vector<ShowtimeId> doomed;
        for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
             it != m_showtimes.end(); ++it) {
            if (it->second.showtime.movieId == _movieId
                && it->second.showtime.theaterId == _theaterId) {
                doomed.push_back(it->first);
            }
        }
        for (std::size_t i = 0; i < doomed.size(); ++i) {
            eraseShowtimeLocked(doomed[i]);
        }

        // A slot generated for this movie may clash with another movie already
        // scheduled in the same hall. Skipping the clash rather than failing
        // the whole call is the friendlier behaviour: the administrator gets
        // the slots that were actually free.
        for (std::size_t i = 0; i < startTimes.size(); ++i) {
            bool occupied = false;
            for (std::map<ShowtimeId, ShowtimeRecord>::const_iterator it = m_showtimes.begin();
                 it != m_showtimes.end(); ++it) {
                if (it->second.showtime.theaterId == _theaterId
                    && it->second.showtime.startTime == startTimes[i]) {
                    occupied = true;
                    break;
                }
            }
            if (occupied) {
                MB_LOG_WARN("default schedule: skipping {} in theater {} - slot taken",
                            schedule::formatTimeOfDay(startTimes[i]), _theaterId);
                continue;
            }

            Showtime showtime;
            showtime.id = m_showtimeIds.next();
            showtime.movieId = _movieId;
            showtime.theaterId = _theaterId;
            showtime.startTime = startTimes[i];
            showtime.seatCapacity = theater.seatCapacity;
            showtime.seatsPerRow = theater.seatsPerRow;

            const SeatMap seats(showtime.seatCapacity, showtime.seatsPerRow);
            m_showtimes.insert(std::make_pair(showtime.id,
                                              ShowtimeRecord(showtime, seats)));
            created.push_back(showtime);
        }
    }

    MB_LOG_INFO("default schedule applied: {} showtimes for movie {} in theater {}",
                created.size(), _movieId, _theaterId);
    notifyChanged();
    return created;
}

} // namespace moviebackend
