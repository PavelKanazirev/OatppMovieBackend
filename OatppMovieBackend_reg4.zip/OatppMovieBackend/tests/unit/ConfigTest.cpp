/**
 * @file ConfigTest.cpp
 * @brief Tests for config.json parsing.
 *
 * The "capacity defaults to 20 but is configurable" requirement is a config
 * concern, so it is pinned down here.
 */
#include "moviebackend/Config.hpp"

#include "moviebackend/Errors.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

using moviebackend::Config;
using moviebackend::ErrorCode;

namespace {
TEST(ConfigTest, EmptyDocumentYieldsDocumentedDefaults)
{
    const Config config = Config::loadFromString("{}", "<test>");

    EXPECT_EQ(20, config.theaterDefaults.seatCapacity);
    EXPECT_EQ(10, config.theaterDefaults.seatsPerRow);

    EXPECT_EQ("0.0.0.0", config.server.host);
    EXPECT_EQ(8000, config.server.port);

    EXPECT_EQ(9 * 60, config.schedule.dayStart);
    EXPECT_EQ(21 * 60, config.schedule.dayEnd);

    EXPECT_EQ("config/catalog.json", config.catalog.path);
    EXPECT_TRUE(config.catalog.autosave);
    EXPECT_EQ(500, config.catalog.autosaveDebounceMs);

    EXPECT_EQ("info", config.logging.level);
}

TEST(ConfigTest, RejectsMalformedJson)
{
    EXPECT_SERVICE_ERROR(Config::loadFromString("{ not json", "<test>"),
                         ErrorCode::InvalidArgument);
    EXPECT_SERVICE_ERROR(Config::loadFromString("[]", "<test>"),
                         ErrorCode::InvalidArgument);
}

}
