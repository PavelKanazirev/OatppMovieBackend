/**
 * @file ScheduleTest.cpp
 * @brief Tests for time parsing and the default-timeline rule.
 *
 * The generation rule is stated in prose in the requirements ("starting from
 * 9:00 a.m. to 21:00 p.m., next one starting at a round hour after the
 * timeline"), so these tests are where that prose is pinned down to something
 * unambiguous.
 */
#include "moviebackend/Schedule.hpp"

#include "moviebackend/Errors.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

using moviebackend::ErrorCode;
using moviebackend::MinutesSinceMidnight;
using moviebackend::ScheduleConfig;
namespace schedule = moviebackend::schedule;

namespace {
TEST(ScheduleTest, ParseAndFormatRoundTrip)
{
    for (MinutesSinceMidnight minutes = 0; minutes < 1440; ++minutes) {
        const std::string text = schedule::formatTimeOfDay(minutes);
        EXPECT_EQ(minutes, schedule::parseTimeOfDay(text)) << "at '" << text << "'";
    }
}

TEST(ScheduleTest, DefaultScheduleForA110MinuteFilm)
{
    ScheduleConfig config;

    const std::vector<MinutesSinceMidnight> starts =
        schedule::generateDefaultStartTimes(110, config);

    const std::vector<std::string> expected = {
        "09:00", "11:00", "13:00", "15:00", "17:00", "19:00", "21:00"
    };

    ASSERT_EQ(expected.size(), starts.size());
    for (std::size_t i = 0; i < expected.size(); ++i) {
        EXPECT_EQ(expected[i], schedule::formatTimeOfDay(starts[i])) << "slot " << i;
    }
}

}
