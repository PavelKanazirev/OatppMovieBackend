/**
 * @file AdminServiceTest.cpp
 * @brief Tests for the administrative facade.
 *
 * Covers each requirement from the "special user" list: append/modify/remove
 * theaters, append/modify/remove movies, the default timeline, and
 * append/modify/remove of individual time slots.
 */
#include "moviebackend/AdminService.hpp"

#include "moviebackend/Errors.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

using moviebackend::AdminService;
using moviebackend::Catalog;
using moviebackend::CatalogSnapshot;
using moviebackend::ErrorCode;
using moviebackend::Movie;
using moviebackend::ScheduleConfig;
using moviebackend::Showtime;
using moviebackend::Theater;
using moviebackend::TheaterDefaults;
using moviebackend::testsupport::InMemoryCatalogStore;
using moviebackend::testsupport::makeMovie;
using moviebackend::testsupport::makeTheater;
namespace schedule = moviebackend::schedule;

namespace {
class AdminServiceTest : public ::testing::Test {
protected:
    AdminServiceTest()
        : m_defaults()
        , m_catalog(m_defaults)
        , m_store()
        , m_schedule()
        , m_service(m_catalog, m_store, m_schedule)
    {
    }

    void SetUp() override
    {
        m_catalog.addMovie(makeMovie("m1", "The Silent Protocol", 110));
        m_catalog.addTheater(makeTheater("t1", "Cinema Central", 20, 10));
    }

    TheaterDefaults      m_defaults;
    Catalog              m_catalog;
    InMemoryCatalogStore m_store;
    ScheduleConfig       m_schedule;
    AdminService         m_service;
};

TEST_F(AdminServiceTest, AppendsModifiesAndRemovesAMovie)
{
    const Movie added = m_service.addMovie(makeMovie("", "Fresh Film", 100));
    EXPECT_FALSE(added.id.empty());
    EXPECT_EQ(2u, m_service.listMovies().size());

    const Movie updated =
        m_service.updateMovie(added.id, makeMovie(added.id, "Renamed Film", 120));
    EXPECT_EQ("Renamed Film", updated.title);
    EXPECT_EQ(120, updated.durationMinutes);

    m_service.removeMovie(added.id);
    EXPECT_EQ(1u, m_service.listMovies().size());
}

TEST_F(AdminServiceTest, DefaultScheduleFollowsTheNineToTwentyOneRule)
{
    const std::vector<Showtime> created = m_service.applyDefaultSchedule("m1", "t1");

    const std::vector<std::string> expected = {
        "09:00", "11:00", "13:00", "15:00", "17:00", "19:00", "21:00"
    };

    ASSERT_EQ(expected.size(), created.size());
    for (std::size_t i = 0; i < expected.size(); ++i) {
        EXPECT_EQ(expected[i], schedule::formatTimeOfDay(created[i].startTime));
    }
}

TEST_F(AdminServiceTest, SaveWritesSynchronously)
{
    m_service.applyDefaultSchedule("m1", "t1");

    EXPECT_EQ(0u, m_store.saveCount());
    m_service.saveCatalog();
    EXPECT_EQ(1u, m_store.saveCount());

    const CatalogSnapshot stored = m_store.stored();
    EXPECT_EQ(1u, stored.movies.size());
    EXPECT_EQ(7u, stored.showtimes.size());
}

}
