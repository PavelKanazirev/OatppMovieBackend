/**
 * @file SeatMapTest.cpp
 * @brief Tests for seat labelling and occupancy.
 *
 * The label scheme is the part of the domain most likely to be got subtly
 * wrong (off-by-one on the 1-based seat number, partially filled last rows),
 * so it gets the most detailed tests in the suite.
 */
#include "moviebackend/SeatMap.hpp"

#include "moviebackend/Errors.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

using moviebackend::ErrorCode;
using moviebackend::SeatLabel;
using moviebackend::SeatMap;

namespace {
TEST(SeatMapTest, LabelToIndexRoundTrips)
{
    const SeatMap seats(20, 10);

    for (std::size_t i = 0; i < 20; ++i) {
        const SeatLabel label = seats.indexToLabel(i);
        const std::optional<std::size_t> index = seats.labelToIndex(label);

        ASSERT_TRUE(index.has_value()) << "label '" << label << "' did not map back";
        EXPECT_EQ(i, *index);
    }
}

TEST(SeatMapTest, BookingMarksASeatAndIsNotRepeatable)
{
    SeatMap seats(20, 10);

    seats.book("a1");

    EXPECT_FALSE(seats.isFree("a1"));
    EXPECT_TRUE(seats.isFree("a2"));
    EXPECT_EQ(19, seats.availableCount());

    EXPECT_SERVICE_ERROR(seats.book("a1"), ErrorCode::SeatUnavailable);
}

TEST(SeatMapTest, ShrinkingIsRefusedWhenItWouldDropABookedSeat)
{
    SeatMap seats(20, 10);
    seats.book("b5");

    EXPECT_SERVICE_ERROR(seats.relayout(10, 10), ErrorCode::Conflict);

    EXPECT_EQ(20, seats.capacity());
    EXPECT_FALSE(seats.isFree("b5"));
    EXPECT_EQ(19, seats.availableCount());
}

}
