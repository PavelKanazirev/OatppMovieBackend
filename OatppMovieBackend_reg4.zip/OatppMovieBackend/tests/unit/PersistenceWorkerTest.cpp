/**
 * @file PersistenceWorkerTest.cpp
 * @brief Tests for the background writer thread.
 *
 * These tests are all about *timing*, which makes them the easiest ones in
 * the suite to write in a flaky way. The rule followed here: never assert
 * "this happened within N milliseconds". Instead, drive the worker and then
 * block on waitForIdle(), which is a condition-variable wait rather than a
 * sleep. The only timeouts present are generous upper bounds whose expiry
 * means a genuine failure (a deadlock), not a slow machine.
 */
#include "moviebackend/PersistenceWorker.hpp"

#include "moviebackend/Catalog.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

#include <chrono>
#include <memory>

using moviebackend::Catalog;
using moviebackend::CatalogSnapshot;
using moviebackend::PersistenceWorker;
using moviebackend::Showtime;
using moviebackend::TheaterDefaults;
using moviebackend::testsupport::InMemoryCatalogStore;
using moviebackend::testsupport::makeMovie;
using moviebackend::testsupport::makeTheater;

namespace {
/** Generous - its expiry means a hang, not a slow machine. */
constexpr std::chrono::milliseconds kFlushTimeout(10000);

class PersistenceWorkerTest : public ::testing::Test {
protected:
    PersistenceWorkerTest()
        : m_defaults()
        , m_catalog(m_defaults)
        , m_store()
    {
    }

    void seedCatalog()
    {
        m_catalog.addMovie(makeMovie("m1", "Persisted", 100));
        m_catalog.addTheater(makeTheater("t1", "Hall", 20, 10));

        Showtime showtime;
        showtime.id = "s1";
        showtime.movieId = "m1";
        showtime.theaterId = "t1";
        showtime.startTime = 9 * 60;
        m_catalog.addShowtime(showtime);
    }

    TheaterDefaults       m_defaults;
    Catalog               m_catalog;
    InMemoryCatalogStore  m_store;
};

TEST_F(PersistenceWorkerTest, ChangesReachTheStoreWithoutAnyPolling)
{
    PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(0));

    m_catalog.addMovie(makeMovie("m1", "Written", 100));

    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout)) << "the worker never caught up";

    const CatalogSnapshot stored = m_store.stored();
    ASSERT_EQ(1u, stored.movies.size());
    EXPECT_EQ("Written", stored.movies[0].title);
}

TEST_F(PersistenceWorkerTest, ConcurrentBookingsAllReachTheStore)
{
    seedCatalog();

    PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(10));

    const int threadCount = 8;
    std::vector<std::thread> threads;

    for (int t = 0; t < threadCount; ++t) {
        const std::string seat = "a" + std::to_string(t + 1);
        threads.push_back(std::thread([this, seat]() {
            try {
                m_catalog.bookSeats("s1", {seat}, "racer");
            } catch (const moviebackend::ServiceError&) {
            }
        }));
    }
    for (std::size_t i = 0; i < threads.size(); ++i) {
        threads[i].join();
    }

    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout));

    const CatalogSnapshot stored = m_store.stored();
    ASSERT_EQ(1u, stored.showtimes.size());
    EXPECT_EQ(m_catalog.listBookedSeats("s1").size(),
              stored.showtimes[0].bookedSeats.size());
    EXPECT_EQ(m_catalog.listBookings().size(), stored.bookings.size());
}

}
