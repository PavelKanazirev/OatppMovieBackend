/**
 * @file JsonCatalogStoreTest.cpp
 * @brief Tests for catalog serialisation and deserialisation.
 */
#include "moviebackend/CatalogStore.hpp"

#include "moviebackend/Catalog.hpp"
#include "moviebackend/Errors.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

#include <filesystem>
#include <fstream>
#include <string>

using moviebackend::Booking;
using moviebackend::Catalog;
using moviebackend::CatalogSnapshot;
using moviebackend::ErrorCode;
using moviebackend::JsonCatalogStore;
using moviebackend::ShowtimeSnapshot;
using moviebackend::TheaterDefaults;
using moviebackend::testsupport::makeMovie;
using moviebackend::testsupport::makeTheater;

namespace {
/** @brief Creates and removes a unique temporary directory per test. */
class JsonCatalogStoreTest : public ::testing::Test {
protected:
    void SetUp() override
    {
        const ::testing::TestInfo* info =
            ::testing::UnitTest::GetInstance()->current_test_info();

        m_directory = std::filesystem::temp_directory_path()
                      / ("moviebackend-test-" + std::string(info->name()));

        std::filesystem::remove_all(m_directory);
        std::filesystem::create_directories(m_directory);

        m_path = (m_directory / "catalog.json").string();
    }

    void TearDown() override
    {
        std::error_code ignored;
        std::filesystem::remove_all(m_directory, ignored);
    }

    /** @brief A snapshot with one of everything. */
    static CatalogSnapshot makeSampleSnapshot()
    {
        CatalogSnapshot snapshot;
        snapshot.movies.push_back(makeMovie("m1", "The Silent Protocol", 110));
        snapshot.theaters.push_back(makeTheater("t1", "Cinema Central", 20, 10));

        ShowtimeSnapshot showtime;
        showtime.showtime.id = "s1";
        showtime.showtime.movieId = "m1";
        showtime.showtime.theaterId = "t1";
        showtime.showtime.startTime = 9 * 60;
        showtime.showtime.seatCapacity = 20;
        showtime.showtime.seatsPerRow = 10;
        showtime.bookedSeats.push_back("a1");
        showtime.bookedSeats.push_back("a2");
        snapshot.showtimes.push_back(showtime);

        Booking booking;
        booking.id = "b1";
        booking.showtimeId = "s1";
        booking.seats.push_back("a1");
        booking.seats.push_back("a2");
        booking.customerName = "Alice";
        booking.createdAtEpochSeconds = 1700000000;
        snapshot.bookings.push_back(booking);

        return snapshot;
    }

    std::filesystem::path m_directory;
    std::string           m_path;
    TheaterDefaults       m_defaults;
};

TEST_F(JsonCatalogStoreTest, RoundTripsThroughAFile)
{
    JsonCatalogStore store(m_path, m_defaults);
    const CatalogSnapshot original = makeSampleSnapshot();

    store.save(original);
    ASSERT_TRUE(std::filesystem::exists(m_path));

    const CatalogSnapshot loaded = store.load();

    ASSERT_EQ(1u, loaded.movies.size());
    EXPECT_EQ("m1", loaded.movies[0].id);
    EXPECT_EQ("The Silent Protocol", loaded.movies[0].title);
    EXPECT_EQ(110, loaded.movies[0].durationMinutes);

    ASSERT_EQ(1u, loaded.theaters.size());
    EXPECT_EQ(20, loaded.theaters[0].seatCapacity);
    EXPECT_EQ(10, loaded.theaters[0].seatsPerRow);

    ASSERT_EQ(1u, loaded.showtimes.size());
    EXPECT_EQ(9 * 60, loaded.showtimes[0].showtime.startTime);
    ASSERT_EQ(2u, loaded.showtimes[0].bookedSeats.size());
    EXPECT_EQ("a1", loaded.showtimes[0].bookedSeats[0]);

    ASSERT_EQ(1u, loaded.bookings.size());
    EXPECT_EQ("Alice", loaded.bookings[0].customerName);
    EXPECT_EQ(1700000000, loaded.bookings[0].createdAtEpochSeconds);
}

TEST_F(JsonCatalogStoreTest, SavingOverwritesAtomicallyAndLeavesNoTempFile)
{
    JsonCatalogStore store(m_path, m_defaults);

    store.save(makeSampleSnapshot());
    store.save(CatalogSnapshot());

    EXPECT_FALSE(std::filesystem::exists(m_path + ".tmp"));

    const CatalogSnapshot loaded = store.load();
    EXPECT_TRUE(loaded.movies.empty());
}

}
