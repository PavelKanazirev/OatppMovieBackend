/**
 * @file BookingServiceTest.cpp
 * @brief Tests for the end-user facade.
 *
 * These walk the six-step user journey from the requirements in order, which
 * doubles as executable documentation of the intended client flow.
 */
#include "moviebackend/BookingService.hpp"

#include "moviebackend/Errors.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

using moviebackend::Booking;
using moviebackend::BookingService;
using moviebackend::Catalog;
using moviebackend::ErrorCode;
using moviebackend::Movie;
using moviebackend::SeatLabel;
using moviebackend::ShowtimeAvailability;
using moviebackend::Theater;
using moviebackend::TheaterDefaults;
using moviebackend::testsupport::contains;
using moviebackend::testsupport::makeMovie;
using moviebackend::testsupport::makeTheater;

namespace {
class BookingServiceTest : public ::testing::Test {
protected:
    BookingServiceTest()
        : m_defaults()
        , m_catalog(m_defaults)
        , m_service(m_catalog)
    {
    }

    void SetUp() override
    {
        m_catalog.addMovie(makeMovie("m1", "The Silent Protocol", 110));
        m_catalog.addMovie(makeMovie("m2", "Not Scheduled", 90));

        m_catalog.addTheater(makeTheater("t1", "Cinema Central", 20, 10));
        m_catalog.addTheater(makeTheater("t2", "Riverside Plex", 12, 6));

        addShowtime("s1", "m1", "t1", 9 * 60);
        addShowtime("s2", "m1", "t1", 11 * 60);
        addShowtime("s3", "m1", "t2", 13 * 60);
    }

    void addShowtime(const std::string& _id,
                     const std::string& _movieId,
                     const std::string& _theaterId,
                     int _startTime)
    {
        moviebackend::Showtime showtime;
        showtime.id = _id;
        showtime.movieId = _movieId;
        showtime.theaterId = _theaterId;
        showtime.startTime = _startTime;
        m_catalog.addShowtime(showtime);
    }

    TheaterDefaults m_defaults;
    Catalog         m_catalog;
    BookingService  m_service;
};

TEST_F(BookingServiceTest, TheFullUserJourney)
{
    const std::vector<Movie> movies = m_service.listPlayingMovies();
    ASSERT_EQ(1u, movies.size());
    EXPECT_EQ("m1", movies[0].id);

    const Movie movie = m_service.getMovie(movies[0].id);
    EXPECT_EQ("The Silent Protocol", movie.title);

    const std::vector<Theater> theaters =
        m_service.listTheatersShowingMovie(movie.id);
    ASSERT_EQ(2u, theaters.size());

    const std::vector<ShowtimeAvailability> showtimes =
        m_service.listShowtimes(movie.id, theaters[0].id);
    ASSERT_EQ(2u, showtimes.size());
    EXPECT_EQ(20, showtimes[0].totalSeats);
    EXPECT_EQ(20, showtimes[0].availableSeats);

    const std::vector<SeatLabel> seats =
        m_service.listAvailableSeats(showtimes[0].showtime.id);
    ASSERT_EQ(20u, seats.size());
    EXPECT_EQ("a1", seats[0]);
    EXPECT_EQ("a2", seats[1]);
    EXPECT_EQ("a3", seats[2]);

    const Booking booking = m_service.bookSeats(
        showtimes[0].showtime.id, {"a1", "a2", "a3"}, "Alice");

    EXPECT_EQ(3u, booking.seats.size());
    EXPECT_EQ("Alice", booking.customerName);

    const std::vector<SeatLabel> remaining =
        m_service.listAvailableSeats(showtimes[0].showtime.id);
    EXPECT_EQ(17u, remaining.size());
    EXPECT_FALSE(contains(remaining, "a1"));
}

TEST_F(BookingServiceTest, DoubleBookingIsRejected)
{
    m_service.bookSeats("s1", {"a1"}, "Alice");

    EXPECT_SERVICE_ERROR(m_service.bookSeats("s1", {"a1"}, "Bob"),
                         ErrorCode::SeatUnavailable);
}

}
