/**
 * @file CatalogTest.cpp
 * @brief Single-threaded behaviour of the catalog.
 *
 * The concurrent behaviour - the part the exercise is really about - lives in
 * CatalogConcurrencyTest.cpp.
 */
#include "moviebackend/Catalog.hpp"

#include "moviebackend/Errors.hpp"
#include "moviebackend/Schedule.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

using moviebackend::Booking;
using moviebackend::Catalog;
using moviebackend::CatalogSnapshot;
using moviebackend::ErrorCode;
using moviebackend::Movie;
using moviebackend::SeatLabel;
using moviebackend::Showtime;
using moviebackend::ShowtimeSnapshot;
using moviebackend::Theater;
using moviebackend::TheaterDefaults;
using moviebackend::testsupport::contains;
using moviebackend::testsupport::makeMovie;
using moviebackend::testsupport::makeTheater;

namespace {
/**
 * @brief A catalog pre-loaded with two movies, two theaters and showtimes.
 *
 * Design pattern: **Test Fixture**. Every test starts from the same known
 * world so that the assertions read as statements about behaviour rather than
 * about setup.
 */
class CatalogTest : public ::testing::Test {
protected:
    CatalogTest()
        : m_defaults()
        , m_catalog(m_defaults)
    {
    }

    void SetUp() override
    {
        m_catalog.addMovie(makeMovie("m1", "The Silent Protocol", 110));
        m_catalog.addMovie(makeMovie("m2", "Autobahn", 95));

        m_catalog.addTheater(makeTheater("t1", "Cinema Central", 20, 10));
        m_catalog.addTheater(makeTheater("t2", "Riverside Plex", 12, 6));

        Showtime showtime;
        showtime.id = "s1";
        showtime.movieId = "m1";
        showtime.theaterId = "t1";
        showtime.startTime = 9 * 60;
        m_catalog.addShowtime(showtime);

        showtime.id = "s2";
        showtime.startTime = 11 * 60;
        m_catalog.addShowtime(showtime);

        showtime.id = "s3";
        showtime.movieId = "m1";
        showtime.theaterId = "t2";
        showtime.startTime = 13 * 60;
        m_catalog.addShowtime(showtime);
    }

    TheaterDefaults m_defaults;
    Catalog         m_catalog;
};

TEST_F(CatalogTest, SeatsFollowTheTheaterLayout)
{
    const std::vector<SeatLabel> seatsT1 = m_catalog.listAvailableSeats("s1");
    EXPECT_EQ(20u, seatsT1.size());
    EXPECT_EQ("a1", seatsT1.front());
    EXPECT_EQ("b10", seatsT1.back());

    const std::vector<SeatLabel> seatsT2 = m_catalog.listAvailableSeats("s3");
    EXPECT_EQ(12u, seatsT2.size());
    EXPECT_EQ("b6", seatsT2.back());
}

TEST_F(CatalogTest, BookingRemovesSeatsFromAvailability)
{
    const std::vector<SeatLabel> wanted = {"a1", "a2"};
    const Booking booking = m_catalog.bookSeats("s1", wanted, "Alice");

    EXPECT_FALSE(booking.id.empty());
    EXPECT_EQ("s1", booking.showtimeId);
    EXPECT_EQ("Alice", booking.customerName);
    EXPECT_EQ(2u, booking.seats.size());
    EXPECT_GT(booking.createdAtEpochSeconds, 0);

    const std::vector<SeatLabel> available = m_catalog.listAvailableSeats("s1");
    EXPECT_EQ(18u, available.size());
    EXPECT_FALSE(contains(available, "a1"));
    EXPECT_FALSE(contains(available, "a2"));
}

TEST_F(CatalogTest, BookingATakenSeatIsRejected)
{
    m_catalog.bookSeats("s1", {"a1"}, "Alice");

    EXPECT_SERVICE_ERROR(m_catalog.bookSeats("s1", {"a1"}, "Bob"),
                         ErrorCode::SeatUnavailable);
}

TEST_F(CatalogTest, CancellingReleasesTheSeats)
{
    const Booking booking = m_catalog.bookSeats("s1", {"a1", "a2"}, "Alice");

    m_catalog.cancelBooking(booking.id);

    EXPECT_EQ(20u, m_catalog.listAvailableSeats("s1").size());
    EXPECT_SERVICE_ERROR(m_catalog.getBooking(booking.id), ErrorCode::NotFound);

    EXPECT_NO_THROW(m_catalog.bookSeats("s1", {"a1"}, "Bob"));
}

TEST_F(CatalogTest, RemovingAMovieRemovesItsShowtimesAndBookings)
{
    m_catalog.bookSeats("s1", {"a1"}, "Alice");
    ASSERT_EQ(1u, m_catalog.listBookings().size());

    m_catalog.removeMovie("m1");

    EXPECT_SERVICE_ERROR(m_catalog.getShowtime("s1"), ErrorCode::NotFound);
    EXPECT_SERVICE_ERROR(m_catalog.getShowtime("s3"), ErrorCode::NotFound);
    EXPECT_TRUE(m_catalog.listBookings().empty());
}

TEST_F(CatalogTest, SnapshotCapturesEverythingAndRestoreBringsItBack)
{
    const Booking booking = m_catalog.bookSeats("s1", {"a1", "a2"}, "Alice");
    const CatalogSnapshot snapshot = m_catalog.snapshot();

    EXPECT_EQ(2u, snapshot.movies.size());
    EXPECT_EQ(2u, snapshot.theaters.size());
    EXPECT_EQ(3u, snapshot.showtimes.size());
    EXPECT_EQ(1u, snapshot.bookings.size());

    Catalog other(m_defaults);
    other.restore(snapshot);

    EXPECT_EQ(18u, other.listAvailableSeats("s1").size());
    EXPECT_EQ("Alice", other.getBooking(booking.id).customerName);
    EXPECT_EQ(9 * 60, other.getShowtime("s1").startTime);
}

}
