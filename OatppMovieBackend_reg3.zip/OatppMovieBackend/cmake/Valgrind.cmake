#[[
  Valgrind / memcheck QA targets.  Linux and WSL only.

  How this fits a cross-platform project:
    Valgrind does not exist on Windows.  Rather than pretend otherwise, the
    memcheck target is simply not defined on Windows - the Windows build is
    still complete and testable, it just uses the compiler sanitisers or
    Application Verifier instead.  In CI the memcheck node runs on the
    Linux/WSL agent only.

    memcheck-tests   Does the *logic* leak or touch uninitialised memory?
                     Runs the GoogleTest binary under memcheck.  Fully
                     deterministic and safe for CI gating.
]]

if(WIN32)
    message(STATUS "MovieBackend: Valgrind targets skipped (Windows host)")
    return()
endif()

find_program(MOVIEBACKEND_VALGRIND_EXECUTABLE valgrind)

if(NOT MOVIEBACKEND_VALGRIND_EXECUTABLE)
    message(STATUS "MovieBackend: valgrind not found - memcheck target unavailable")
    return()
endif()

set(MOVIEBACKEND_VALGRIND_FLAGS
    --tool=memcheck
    --leak-check=full
    --show-leak-kinds=definite,indirect
    --track-origins=yes
    --errors-for-leak-kinds=definite
    --error-exitcode=99
    "--suppressions=${CMAKE_CURRENT_SOURCE_DIR}/tests/valgrind.supp")

if(MOVIEBACKEND_BUILD_TESTS AND BUILD_TESTING)
    add_custom_target(memcheck-tests
        COMMAND ${MOVIEBACKEND_VALGRIND_EXECUTABLE} ${MOVIEBACKEND_VALGRIND_FLAGS}
                $<TARGET_FILE:moviebackend_tests>
        DEPENDS moviebackend_tests
        COMMENT "Running unit tests under Valgrind memcheck"
        VERBATIM)
endif()

message(STATUS "MovieBackend: memcheck-tests target available")
