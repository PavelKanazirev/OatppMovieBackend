/**
 * @file Logging.cpp
 * @brief Global logger setup.
 */
#include "moviebackend/Logging.hpp"

#include "moviebackend/Errors.hpp"

#include <spdlog/sinks/basic_file_sink.h>
#include <spdlog/sinks/stdout_color_sinks.h>

#include <memory>
#include <vector>

namespace moviebackend {
namespace {
/**
 * @brief Translate a level name from config.json into spdlog's enum.
 * @throws ServiceError InvalidArgument for an unknown name.
 */
spdlog::level::level_enum parseLevel(const std::string& _name)
{
    if (_name == "trace")    { return spdlog::level::trace; }
    if (_name == "debug")    { return spdlog::level::debug; }
    if (_name == "info")     { return spdlog::level::info; }
    if (_name == "warn")     { return spdlog::level::warn; }
    if (_name == "warning")  { return spdlog::level::warn; }
    if (_name == "error")    { return spdlog::level::err; }
    if (_name == "critical") { return spdlog::level::critical; }
    if (_name == "off")      { return spdlog::level::off; }

    throw invalidArgument(
        "unknown log level '" + _name
        + "'; expected one of trace, debug, info, warn, error, critical, off");
}

}

void initialiseLogging(const LoggingConfig& _config)
{
    const spdlog::level::level_enum level = parseLevel(_config.level);

    std::vector<spdlog::sink_ptr> sinks;
    sinks.push_back(std::make_shared<spdlog::sinks::stdout_color_sink_mt>());

    if (!_config.file.empty()) {
        sinks.push_back(std::make_shared<spdlog::sinks::basic_file_sink_mt>(
            _config.file, false));
    }

    std::shared_ptr<spdlog::logger> logger =
        std::make_shared<spdlog::logger>("moviebackend", sinks.begin(), sinks.end());

    logger->set_pattern(_config.pattern);
    logger->set_level(level);

    logger->flush_on(spdlog::level::warn);

    spdlog::set_default_logger(logger);

    spdlog::set_level(level);

    MB_LOG_INFO("logging initialised at level '{}'{}", _config.level,
                _config.file.empty() ? "" : (" -> " + _config.file));
}

void shutdownLogging() noexcept
{
    spdlog::shutdown();
}

}
