/**
 * @file PersistenceWorker.cpp
 * @brief The producer/consumer writer thread.
 *
 * The header explains why a condition variable belongs here and what makes
 * the pattern correct. This file is the implementation of exactly that.
 */
#include "moviebackend/PersistenceWorker.hpp"

#include "moviebackend/Errors.hpp"
#include "moviebackend/Logging.hpp"

namespace moviebackend {
PersistenceWorker::PersistenceWorker(Catalog& _catalog,
                                     CatalogStore& _store,
                                     std::chrono::milliseconds _debounce)
    : m_catalog(_catalog)
    , m_store(_store)
    , m_debounce(_debounce)
{
    m_catalog.setChangeListener(this);

    m_thread = std::thread(&PersistenceWorker::run, this);

    MB_LOG_INFO("persistence worker started (debounce {} ms)", _debounce.count());
}

PersistenceWorker::~PersistenceWorker()
{
    m_catalog.setChangeListener(nullptr);

    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        m_stopRequested = true;
    }

    m_condition.notify_all();

    if (m_thread.joinable()) {
        m_thread.join();
    }

    bool stillDirty = false;
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        stillDirty = m_dirty;
    }
    if (stillDirty) {
        MB_LOG_INFO("persistence worker: final flush on shutdown");
        performSave();
    }

    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        if (m_failedSaveCount > 0) {
            MB_LOG_WARN("persistence worker stopped after {} save(s) and {} "
                        "failed attempt(s)", m_saveCount, m_failedSaveCount);
        } else {
            MB_LOG_INFO("persistence worker stopped after {} save(s)", m_saveCount);
        }
    }
}

void PersistenceWorker::onCatalogChanged() noexcept
{
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        m_dirty = true;
        ++m_pendingGeneration;
    }
    m_condition.notify_all();
}

bool PersistenceWorker::waitForIdle(std::chrono::milliseconds _timeout)
{
    std::unique_lock<std::mutex> lock(m_mutex);

    const std::uint64_t target = m_pendingGeneration;

    const bool caughtUp = m_condition.wait_for(
        lock, _timeout,
        [this, target]() { return m_savedGeneration >= target || m_stopRequested; });

    return caughtUp;
}

std::uint64_t PersistenceWorker::saveCount() const
{
    const std::lock_guard<std::mutex> guard(m_mutex);
    return m_saveCount;
}

void PersistenceWorker::run()
{
    for (;;) {
        std::uint64_t generationBeingSaved = 0;

        {
            std::unique_lock<std::mutex> lock(m_mutex);

            m_condition.wait(lock,
                             [this]() { return m_dirty || m_stopRequested; });

            if (m_stopRequested) {
                return;
            }

            if (m_debounce.count() > 0) {
                m_condition.wait_for(lock, m_debounce,
                                     [this]() { return m_stopRequested; });
            }

            m_dirty = false;
            generationBeingSaved = m_pendingGeneration;
        }

        const bool saved = performSave();

        {
            const std::lock_guard<std::mutex> guard(m_mutex);

            if (saved) {
                if (generationBeingSaved > m_savedGeneration) {
                    m_savedGeneration = generationBeingSaved;
                }
                ++m_saveCount;
            } else {
                m_dirty = true;
                ++m_failedSaveCount;
            }
        }

        m_condition.notify_all();

        if (!saved) {
            std::unique_lock<std::mutex> lock(m_mutex);
            if (m_stopRequested) {
                return;
            }
            m_condition.wait_for(lock, kRetryBackoff,
                                 [this]() { return m_stopRequested; });
        }
    }
}

bool PersistenceWorker::performSave() noexcept
{
    try {
        const CatalogSnapshot snapshot = m_catalog.snapshot();
        m_store.save(snapshot);
        return true;
    } catch (const ServiceError& error) {
        MB_LOG_ERROR("persistence worker: save failed ({}): {}",
                     toString(error.code()), error.what());
    } catch (const std::exception& error) {
        MB_LOG_ERROR("persistence worker: save failed: {}", error.what());
    } catch (...) {
        MB_LOG_ERROR("persistence worker: save failed with an unknown exception");
    }
    return false;
}

}
