/**
 * @file BookingService.cpp
 * @brief End-user use cases. A thin facade over Catalog.
 *
 * Most methods here forward straight to the catalog. That is intentional -
 * the value of the class is that it *names* the six steps of the user journey
 * and gives the REST layer one type to depend on, not that it adds logic.
 * The one method that does more than forward is listShowtimes(), which joins
 * a showtime with its seat counts.
 */
#include "moviebackend/BookingService.hpp"

#include "moviebackend/Errors.hpp"
#include "moviebackend/Logging.hpp"

namespace moviebackend {
BookingService::BookingService(Catalog& _catalog)
    : m_catalog(_catalog)
{
}

std::vector<Movie> BookingService::listPlayingMovies() const
{
    MB_LOG_DEBUG("listing playing movies");
    return m_catalog.listPlayingMovies();
}

Movie BookingService::getMovie(const MovieId& _movieId) const
{
    MB_LOG_DEBUG("fetching movie {}", _movieId);
    return m_catalog.getMovie(_movieId);
}

std::vector<Theater> BookingService::listTheatersShowingMovie(
    const MovieId& _movieId) const
{
    MB_LOG_DEBUG("listing theaters showing movie {}", _movieId);
    return m_catalog.listTheatersShowingMovie(_movieId);
}

std::vector<ShowtimeAvailability> BookingService::listShowtimes(
    const MovieId& _movieId,
    const TheaterId& _theaterId) const
{
    MB_LOG_DEBUG("listing showtimes for movie {} in theater {}", _movieId, _theaterId);

    const std::vector<Showtime> showtimes =
        m_catalog.listShowtimes(_movieId, _theaterId);

    std::vector<ShowtimeAvailability> result;
    result.reserve(showtimes.size());

    for (std::size_t i = 0; i < showtimes.size(); ++i) {
        ShowtimeAvailability entry;
        entry.showtime = showtimes[i];
        entry.totalSeats = showtimes[i].seatCapacity;

        const std::vector<SeatLabel> available =
            m_catalog.listAvailableSeats(showtimes[i].id);
        entry.availableSeats = static_cast<int>(available.size());

        result.push_back(entry);
    }

    return result;
}

Showtime BookingService::getShowtime(const ShowtimeId& _showtimeId) const
{
    MB_LOG_DEBUG("fetching showtime {}", _showtimeId);
    return m_catalog.getShowtime(_showtimeId);
}

std::vector<SeatLabel> BookingService::listAvailableSeats(
    const ShowtimeId& _showtimeId) const
{
    MB_LOG_DEBUG("listing available seats for showtime {}", _showtimeId);
    return m_catalog.listAvailableSeats(_showtimeId);
}

std::vector<SeatLabel> BookingService::listBookedSeats(
    const ShowtimeId& _showtimeId) const
{
    MB_LOG_DEBUG("listing booked seats for showtime {}", _showtimeId);
    return m_catalog.listBookedSeats(_showtimeId);
}

Booking BookingService::bookSeats(const ShowtimeId& _showtimeId,
                                  const std::vector<SeatLabel>& _seats,
                                  const std::string& _customerName)
{
    MB_LOG_DEBUG("booking {} seat(s) for showtime {}", _seats.size(), _showtimeId);

    return m_catalog.bookSeats(_showtimeId, _seats, _customerName);
}

Booking BookingService::getBooking(const BookingId& _bookingId) const
{
    MB_LOG_DEBUG("fetching booking {}", _bookingId);
    return m_catalog.getBooking(_bookingId);
}

void BookingService::cancelBooking(const BookingId& _bookingId)
{
    MB_LOG_DEBUG("cancelling booking {}", _bookingId);
    m_catalog.cancelBooking(_bookingId);
}

}
