/**
 * @file AdminService.cpp
 * @brief Administrative use cases.
 */
#include "moviebackend/AdminService.hpp"

#include "moviebackend/Errors.hpp"
#include "moviebackend/Logging.hpp"
#include "moviebackend/Schedule.hpp"

namespace moviebackend {
AdminService::AdminService(Catalog& _catalog,
                           CatalogStore& _store,
                           const ScheduleConfig& _schedule)
    : m_catalog(_catalog)
    , m_store(_store)
    , m_schedule(_schedule)
{
}

std::vector<Theater> AdminService::listTheaters() const
{
    return m_catalog.listTheaters();
}

Theater AdminService::addTheater(const Theater& _theater)
{
    MB_LOG_INFO("admin: adding theater '{}'", _theater.name);
    return m_catalog.addTheater(_theater);
}

Theater AdminService::updateTheater(const TheaterId& _theaterId, const Theater& _changes)
{
    MB_LOG_INFO("admin: updating theater {}", _theaterId);
    return m_catalog.updateTheater(_theaterId, _changes);
}

void AdminService::removeTheater(const TheaterId& _theaterId)
{
    MB_LOG_INFO("admin: removing theater {}", _theaterId);
    m_catalog.removeTheater(_theaterId);
}

std::vector<Movie> AdminService::listMovies() const
{
    return m_catalog.listAllMovies();
}

Movie AdminService::addMovie(const Movie& _movie)
{
    MB_LOG_INFO("admin: adding movie '{}'", _movie.title);
    return m_catalog.addMovie(_movie);
}

Movie AdminService::updateMovie(const MovieId& _movieId, const Movie& _changes)
{
    MB_LOG_INFO("admin: updating movie {}", _movieId);
    return m_catalog.updateMovie(_movieId, _changes);
}

void AdminService::removeMovie(const MovieId& _movieId)
{
    MB_LOG_INFO("admin: removing movie {}", _movieId);
    m_catalog.removeMovie(_movieId);
}

std::vector<Showtime> AdminService::listShowtimes(const MovieId& _movieId,
                                                  const TheaterId& _theaterId) const
{
    return m_catalog.listShowtimes(_movieId, _theaterId);
}

std::vector<Showtime> AdminService::listAllShowtimes() const
{
    return m_catalog.listAllShowtimes();
}

std::vector<Showtime> AdminService::applyDefaultSchedule(const MovieId& _movieId,
                                                         const TheaterId& _theaterId)
{
    MB_LOG_INFO("admin: applying default schedule for movie {} in theater {}",
                _movieId, _theaterId);
    return m_catalog.applyDefaultSchedule(_movieId, _theaterId, m_schedule);
}

Showtime AdminService::addShowtime(const MovieId& _movieId,
                                   const TheaterId& _theaterId,
                                   MinutesSinceMidnight _startTime)
{
    if (_startTime < m_schedule.dayStart || _startTime > m_schedule.dayEnd) {
        throw invalidArgument(
            "start time " + schedule::formatTimeOfDay(_startTime)
            + " is outside the configured screening day ("
            + schedule::formatTimeOfDay(m_schedule.dayStart) + ".."
            + schedule::formatTimeOfDay(m_schedule.dayEnd) + ")");
    }

    Showtime showtime;
    showtime.movieId = _movieId;
    showtime.theaterId = _theaterId;
    showtime.startTime = _startTime;

    MB_LOG_INFO("admin: adding showtime for movie {} in theater {} at {}",
                _movieId, _theaterId, schedule::formatTimeOfDay(_startTime));

    return m_catalog.addShowtime(showtime);
}

Showtime AdminService::updateShowtime(const ShowtimeId& _showtimeId,
                                      MinutesSinceMidnight _newStartTime)
{
    if (_newStartTime < m_schedule.dayStart || _newStartTime > m_schedule.dayEnd) {
        throw invalidArgument(
            "start time " + schedule::formatTimeOfDay(_newStartTime)
            + " is outside the configured screening day ("
            + schedule::formatTimeOfDay(m_schedule.dayStart) + ".."
            + schedule::formatTimeOfDay(m_schedule.dayEnd) + ")");
    }

    MB_LOG_INFO("admin: moving showtime {} to {}",
                _showtimeId, schedule::formatTimeOfDay(_newStartTime));

    return m_catalog.updateShowtimeStart(_showtimeId, _newStartTime);
}

void AdminService::removeShowtime(const ShowtimeId& _showtimeId)
{
    MB_LOG_INFO("admin: removing showtime {}", _showtimeId);
    m_catalog.removeShowtime(_showtimeId);
}

void AdminService::saveCatalog()
{
    MB_LOG_INFO("admin: forcing a synchronous catalog save");

    const CatalogSnapshot snapshot = m_catalog.snapshot();
    m_store.save(snapshot);
}

void AdminService::reloadCatalog()
{
    MB_LOG_WARN("admin: reloading the catalog from disk - in-memory changes "
                "since the last save will be lost");

    const CatalogSnapshot snapshot = m_store.load();
    m_catalog.restore(snapshot);
}

}
