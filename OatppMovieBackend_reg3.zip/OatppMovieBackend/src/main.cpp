/**
 * @file main.cpp
 * @brief Process entry point: configuration, object lifetimes, shutdown.
 *
 * =========================================================================
 *  OBJECT LIFETIMES - the one thing to get right in this file
 * =========================================================================
 *
 * Several objects here hold *references* to each other rather than owning
 * them, which is only safe because construction order guarantees the
 * referent outlives the holder. Objects are destroyed in reverse order of
 * construction, so the order below is the whole safety argument:
 *
 *     1. Catalog            <- outlives everything; owns the state and the lock
 *     2. JsonCatalogStore   <- outlives the worker and the admin service
 *     3. PersistenceWorker  <- registers itself with the catalog, starts a thread
 *     4. BookingService     <- references the catalog
 *     5. AdminService       <- references the catalog and the store
 *     6. RestServer         <- references both services, starts accepting
 *
 * Destruction therefore runs 6 -> 1: the server stops accepting first, then
 * the services go, then the worker stops its thread and flushes, then the
 * store, then the catalog. At no point does a live object hold a reference to
 * a destroyed one.
 *
 * Everything is a stack object or a std::unique_ptr. There is no shared
 * ownership in this file.
 */
#include "moviebackend/AdminService.hpp"
#include "moviebackend/BookingService.hpp"
#include "moviebackend/Catalog.hpp"
#include "moviebackend/CatalogStore.hpp"
#include "moviebackend/Config.hpp"
#include "moviebackend/Errors.hpp"
#include "moviebackend/Logging.hpp"
#include "moviebackend/PersistenceWorker.hpp"
#include "moviebackend/RestServer.hpp"

#include "oatpp/core/base/Environment.hpp"

#include <atomic>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <exception>
#include <iostream>
#include <memory>
#include <string>
#include <thread>

namespace {
/**
 * @brief Set when SIGINT/SIGTERM arrives, or when main() is done waiting.
 *
 * `std::atomic<bool>` is lock-free on every platform we target, and a
 * lock-free atomic store is one of the very few things a signal handler is
 * actually allowed to do.
 */
std::atomic<bool> g_shutdownRequested{false};

/**
 * @brief CALLBACK - SIGINT / SIGTERM handler.
 *
 * Async-signal-safety is the constraint that shapes this function, and it is
 * a harsher constraint than it looks. A handler runs by hijacking whichever
 * thread happened to receive the signal, so it may interrupt that thread at
 * *any* instruction - including one holding a mutex. Calling anything that
 * takes that same mutex then self-deadlocks, and the process hangs with no
 * stack trace to explain why.
 *
 * That rules out malloc, printf, and - the one that bit this project - the
 * logger: spdlog's thread-safe sinks take a mutex and allocate. Calling
 * RestServer::requestStop() directly from here was a latent deadlock, because
 * it logs.
 *
 * So the handler does exactly one legal thing: a lock-free atomic store. The
 * actual shutdown is performed by watchForShutdown() below, on an ordinary
 * thread where locking is fine.
 *
 * @param _signalNumber the signal being delivered (unused)
 */
extern "C" void handleShutdownSignal(int _signalNumber)
{
    (void)_signalNumber;
    g_shutdownRequested.store(true);
}

/**
 * @brief Watches the shutdown flag and performs the actual stop.
 *
 * Runs on its own thread for the reason given above: everything
 * RestServer::requestStop() does - taking locks, logging, closing a socket -
 * is safe on a normal thread and unsafe in a signal handler.
 *
 * Polling rather than a condition variable is deliberate: notifying a CV is
 * itself not async-signal-safe, so the handler could not wake us. A 100 ms
 * poll costs nothing measurable and bounds Ctrl+C latency at 100 ms.
 *
 * The loop also exits when main() sets the flag itself after the accept loop
 * has returned for some other reason, so this thread is always joinable.
 *
 * @param _server the server to stop; must outlive this thread
 */
void watchForShutdown(moviebackend::RestServer* _server)
{
    while (!g_shutdownRequested.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    if (_server != nullptr) {
        _server->requestStop();
    }
}

/**
 * @brief Read the config file path from the command line.
 *
 * Usage: `moviebackend [path/to/config.json]`
 *
 * @return the given path, or "config/config.json" when none was supplied
 */
std::string resolveConfigPath(int _argc, char** _argv)
{
    if (_argc > 1) {
        return std::string(_argv[1]);
    }
    return std::string("config/config.json");
}

}

int main(int argc, char** argv)
{
    using namespace moviebackend;

    Config config;
    const std::string configPath = resolveConfigPath(argc, argv);

    try {
        config = Config::loadFromFile(configPath);
    } catch (const ServiceError& error) {
        std::cerr << "moviebackend: cannot load configuration: "
                  << error.what() << "\n"
                  << "usage: " << argv[0] << " [path/to/config.json]\n";
        return EXIT_FAILURE;
    }

    try {
        initialiseLogging(config.logging);
    } catch (const ServiceError& error) {
        std::cerr << "moviebackend: cannot initialise logging: "
                  << error.what() << "\n";
        return EXIT_FAILURE;
    }

    MB_LOG_INFO("moviebackend starting (config '{}')", configPath);
    MB_LOG_INFO("theater default capacity {} seats, {} per row",
                config.theaterDefaults.seatCapacity,
                config.theaterDefaults.seatsPerRow);

    oatpp::base::Environment::init();

    int exitCode = EXIT_SUCCESS;

    try {
        Catalog catalog(config.theaterDefaults);

        JsonCatalogStore store(config.catalog.path, config.theaterDefaults);

        try {
            catalog.restore(store.load());
        } catch (const ServiceError& error) {
            MB_LOG_CRITICAL("cannot load catalog '{}': {}",
                            config.catalog.path, error.what());
            MB_LOG_CRITICAL("fix the file or point catalog.path elsewhere");
            oatpp::base::Environment::destroy();
            shutdownLogging();
            return EXIT_FAILURE;
        }

        std::unique_ptr<PersistenceWorker> persistenceWorker;
        if (config.catalog.autosave) {
            persistenceWorker.reset(new PersistenceWorker(
                catalog, store,
                std::chrono::milliseconds(config.catalog.autosaveDebounceMs)));
        } else {
            MB_LOG_WARN("autosave is disabled - the catalog is only written "
                        "when POST /api/v1/admin/catalog/save is called");
        }

        BookingService bookingService(catalog);
        AdminService adminService(catalog, store, config.schedule);

        RestServer server(config.server, bookingService, adminService);

        std::thread signalWatcher(watchForShutdown, &server);

        std::signal(SIGINT, handleShutdownSignal);
        std::signal(SIGTERM, handleShutdownSignal);

        MB_LOG_INFO("listening on http://{}:{} - press Ctrl+C to stop",
                    config.server.host, server.boundPort());
        MB_LOG_INFO("end-user API under /api/v1, admin API under /api/v1/admin");

        server.start();

        MB_LOG_INFO("shutting down");

        std::signal(SIGINT, SIG_DFL);
        std::signal(SIGTERM, SIG_DFL);

        g_shutdownRequested.store(true);
        signalWatcher.join();

        if (persistenceWorker != nullptr) {
            if (!persistenceWorker->waitForIdle(std::chrono::seconds(5))) {
                MB_LOG_WARN("persistence worker did not finish within 5s");
            }
        }

    } catch (const ServiceError& error) {
        MB_LOG_CRITICAL("fatal: {} ({})", error.what(), toString(error.code()));
        exitCode = EXIT_FAILURE;
    } catch (const std::exception& error) {
        MB_LOG_CRITICAL("fatal: {}", error.what());
        exitCode = EXIT_FAILURE;
    } catch (...) {
        MB_LOG_CRITICAL("fatal: unknown exception");
        exitCode = EXIT_FAILURE;
    }

    oatpp::base::Environment::destroy();

    MB_LOG_INFO("moviebackend stopped");
    shutdownLogging();

    return exitCode;
}
