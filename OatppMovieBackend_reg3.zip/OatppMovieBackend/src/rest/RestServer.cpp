/**
 * @file RestServer.cpp
 * @brief Wiring and lifecycle of the oatpp HTTP stack.
 *
 * ## Why the components are wired by hand
 *
 * oatpp's documented style uses the OATPP_CREATE_COMPONENT macro, which
 * registers each component in a global registry and requires a lambda per
 * component. That is convenient in a large application with many optional
 * pieces. Here it would mean five lambdas and a hidden global, in exchange for
 * nothing - this service has exactly one server with a fixed set of parts.
 *
 * Constructing them explicitly in the constructor below makes the dependency
 * order visible (mapper -> router -> controllers -> handler -> provider ->
 * server) and keeps the codebase free of lambdas it does not need.
 *
 * ## The shared_ptr exception, restated
 *
 * Every handle in Impl is a std::shared_ptr because oatpp's factories return
 * them and its APIs take them. This is the one place in the project where
 * that is true, and it is a constraint of the framework rather than a design
 * choice. Nothing outside this file sees a shared_ptr.
 */
#include "moviebackend/RestServer.hpp"

#include "moviebackend/Errors.hpp"
#include "moviebackend/Logging.hpp"
#include "rest/AdminController.hpp"
#include "rest/ErrorHandler.hpp"
#include "rest/PublicController.hpp"

#include "oatpp/network/Server.hpp"
#include "oatpp/network/ConnectionProvider.hpp"
#include "oatpp/network/tcp/server/ConnectionProvider.hpp"
#include "oatpp/parser/json/mapping/ObjectMapper.hpp"
#include "oatpp/web/server/HttpConnectionHandler.hpp"
#include "oatpp/web/server/HttpRouter.hpp"

#include <atomic>
#include <exception>
#include <string>

namespace moviebackend {
/**
 * @brief Everything oatpp needs, hidden from the public header (PIMPL).
 */
struct RestServer::Impl {
    std::shared_ptr<oatpp::parser::json::mapping::ObjectMapper> objectMapper;
    std::shared_ptr<oatpp::web::server::HttpRouter>             router;
    std::shared_ptr<rest::RestErrorHandler>                     errorHandler;
    std::shared_ptr<rest::PublicController>                     publicController;
    std::shared_ptr<rest::AdminController>                      adminController;
    std::shared_ptr<oatpp::web::server::HttpConnectionHandler>  connectionHandler;
    std::shared_ptr<oatpp::network::tcp::server::ConnectionProvider> connectionProvider;
    std::shared_ptr<oatpp::network::Server>                     server;

    /**
     * Guards against a stop request that arrives *before* start() has begun
     * listening, and makes requestStop() idempotent.
     */
    std::atomic<bool> stopRequested{false};
};

RestServer::RestServer(const ServerConfig& _serverConfig,
                       BookingService& _bookingService,
                       AdminService& _adminService)
    : m_impl(new Impl())
{
    m_impl->objectMapper = oatpp::parser::json::mapping::ObjectMapper::createShared();

    m_impl->objectMapper->getSerializer()->getConfig()->includeNullFields = false;

    m_impl->router = oatpp::web::server::HttpRouter::createShared();
    m_impl->errorHandler = std::make_shared<rest::RestErrorHandler>(m_impl->objectMapper);

    m_impl->publicController =
        std::make_shared<rest::PublicController>(m_impl->objectMapper, _bookingService);
    m_impl->adminController =
        std::make_shared<rest::AdminController>(m_impl->objectMapper, _adminService);

    m_impl->router->addController(m_impl->publicController);
    m_impl->router->addController(m_impl->adminController);

    m_impl->connectionHandler =
        oatpp::web::server::HttpConnectionHandler::createShared(m_impl->router);
    m_impl->connectionHandler->setErrorHandler(m_impl->errorHandler);

    const oatpp::network::Address address(_serverConfig.host,
                                          _serverConfig.port,
                                          oatpp::network::Address::IP_4);
    try {
        m_impl->connectionProvider =
            oatpp::network::tcp::server::ConnectionProvider::createShared(address);
    } catch (const std::exception& error) {
        throw ServiceError(ErrorCode::Internal,
                           "cannot listen on " + _serverConfig.host + ":"
                               + std::to_string(_serverConfig.port) + " - "
                               + error.what());
    }

    m_impl->server = std::make_shared<oatpp::network::Server>(
        m_impl->connectionProvider, m_impl->connectionHandler);

    MB_LOG_INFO("REST server ready on {}:{}", _serverConfig.host, boundPort());
}

RestServer::~RestServer()
{
    requestStop();

    if (m_impl->connectionHandler != nullptr) {
        m_impl->connectionHandler->stop();
    }
}

void RestServer::start()
{
    if (m_impl->stopRequested.load()) {
        MB_LOG_WARN("REST server: start() called after a stop request - not starting");
        return;
    }

    MB_LOG_INFO("REST server: entering accept loop");

    m_impl->server->run();

    MB_LOG_INFO("REST server: accept loop finished");
}

void RestServer::requestStop() noexcept
{
    if (m_impl->stopRequested.exchange(true)) {
        return;
    }

    MB_LOG_INFO("REST server: stop requested");

    if (m_impl->server != nullptr) {
        m_impl->server->stop();
    }
    if (m_impl->connectionProvider != nullptr) {
        m_impl->connectionProvider->stop();
    }
}

std::uint16_t RestServer::boundPort() const noexcept
{
    if (m_impl->connectionProvider == nullptr) {
        return 0;
    }

    const oatpp::data::share::StringKeyLabel portProperty =
        m_impl->connectionProvider->getProperty(
            oatpp::network::ConnectionProvider::PROPERTY_PORT);

    if (portProperty) {
        const oatpp::String portText = portProperty.toString();
        if (portText.get() != nullptr) {
            try {
                const int parsed = std::stoi(portText->c_str());
                if (parsed > 0 && parsed <= 65535) {
                    return static_cast<std::uint16_t>(parsed);
                }
            } catch (const std::exception&) {
            }
        }
    }

    return m_impl->connectionProvider->getAddress().port;
}

}
