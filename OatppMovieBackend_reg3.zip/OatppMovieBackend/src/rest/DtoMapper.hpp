/**
 * @file DtoMapper.hpp
 * @brief Translation between domain types and wire DTOs.
 *
 * This is the *only* file allowed to know about both sides. Keeping the
 * conversions here rather than inline in the controllers means:
 *   * a controller method reads as "call the service, map, respond";
 *   * a field renamed on the wire is a change in one file;
 *   * the conversions are ordinary functions, so they are easy to follow.
 *
 * Every function is `inline` and free - there is no state to hold.
 */
#ifndef MOVIEBACKEND_DTOMAPPER_HPP
#define MOVIEBACKEND_DTOMAPPER_HPP

#include "moviebackend/BookingService.hpp"
#include "moviebackend/Domain.hpp"
#include "moviebackend/Errors.hpp"
#include "moviebackend/Schedule.hpp"
#include "rest/dto/Dtos.hpp"

#include <string>
#include <vector>

namespace moviebackend {
namespace rest {
/** @brief Convert a list of seat labels to an oatpp string vector. */
inline oatpp::Vector<oatpp::String> toDto(const std::vector<SeatLabel>& _labels)
{
    oatpp::Vector<oatpp::String> result = oatpp::Vector<oatpp::String>::createShared();
    for (std::size_t i = 0; i < _labels.size(); ++i) {
        result->push_back(_labels[i]);
    }
    return result;
}

/** @brief Convert a Movie to its wire representation. */
inline oatpp::Object<MovieDto> toDto(const Movie& _movie)
{
    oatpp::Object<MovieDto> dto = MovieDto::createShared();
    dto->id = _movie.id;
    dto->title = _movie.title;
    dto->durationMinutes = _movie.durationMinutes;
    dto->language = _movie.language;
    dto->genre = _movie.genre;
    return dto;
}

/** @brief Convert a Theater to its wire representation. */
inline oatpp::Object<TheaterDto> toDto(const Theater& _theater)
{
    oatpp::Object<TheaterDto> dto = TheaterDto::createShared();
    dto->id = _theater.id;
    dto->name = _theater.name;
    dto->city = _theater.city;
    dto->seatCapacity = _theater.seatCapacity;
    dto->seatsPerRow = _theater.seatsPerRow;
    return dto;
}

/**
 * @brief Convert a Showtime, formatting the start time for humans.
 *
 * availableSeats is left unset (JSON null) because a bare Showtime does not
 * carry it; the overload below fills it in.
 */
inline oatpp::Object<ShowtimeDto> toDto(const Showtime& _showtime)
{
    oatpp::Object<ShowtimeDto> dto = ShowtimeDto::createShared();
    dto->id = _showtime.id;
    dto->movieId = _showtime.movieId;
    dto->theaterId = _showtime.theaterId;
    dto->startTime = schedule::formatTimeOfDay(_showtime.startTime);
    dto->seatCapacity = _showtime.seatCapacity;
    return dto;
}

/** @brief Convert a showtime together with its availability counts. */
inline oatpp::Object<ShowtimeDto> toDto(const ShowtimeAvailability& _availability)
{
    oatpp::Object<ShowtimeDto> dto = toDto(_availability.showtime);
    dto->availableSeats = _availability.availableSeats;
    dto->seatCapacity = _availability.totalSeats;
    return dto;
}

/** @brief Convert a Booking to its wire representation. */
inline oatpp::Object<BookingDto> toDto(const Booking& _booking)
{
    oatpp::Object<BookingDto> dto = BookingDto::createShared();
    dto->id = _booking.id;
    dto->showtimeId = _booking.showtimeId;
    dto->seats = toDto(_booking.seats);
    dto->customerName = _booking.customerName;
    dto->createdAt = _booking.createdAtEpochSeconds;
    return dto;
}

/**
 * @brief Convert a vector of domain values to a vector of DTOs.
 *
 * Modern C++ note: this is a function template so that one definition covers
 * movies, theaters and showtimes. It relies on the `toDto` overloads above
 * being found by overload resolution on the element type - the only piece of
 * generic programming in the codebase, and it replaces three near-identical
 * loops.
 *
 * @tparam DtoType    the wire type to produce
 * @tparam DomainType the domain type to read
 */
template <typename DtoType, typename DomainType>
inline oatpp::Vector<oatpp::Object<DtoType> > toDtoList(
    const std::vector<DomainType>& _values)
{
    oatpp::Vector<oatpp::Object<DtoType> > result =
        oatpp::Vector<oatpp::Object<DtoType> >::createShared();

    for (std::size_t i = 0; i < _values.size(); ++i) {
        result->push_back(toDto(_values[i]));
    }
    return result;
}

/**
 * @brief Read a required oatpp string.
 * @param _value the field
 * @param _fieldName used in the error message
 * @throws ServiceError InvalidArgument if the field is null or empty.
 */
inline std::string requireString(const oatpp::String& _value,
                                 const std::string& _fieldName)
{
    if (_value.get() == nullptr || _value->empty()) {
        throw invalidArgument("field '" + _fieldName + "' is required");
    }
    return *_value;
}

/** @brief Read an optional oatpp string, defaulting to empty. */
inline std::string optionalString(const oatpp::String& _value)
{
    if (_value.get() == nullptr) {
        return std::string();
    }
    return *_value;
}

/** @brief Read an optional oatpp int, defaulting to @p fallback. */
inline int optionalInt(const oatpp::Int32& _value, int _fallback)
{
    if (_value.get() == nullptr) {
        return _fallback;
    }
    return *_value;
}

/**
 * @brief Extract the seat list from a booking request body.
 * @throws ServiceError InvalidArgument if the body or the list is missing or
 *         empty, or if any entry is null.
 */
inline std::vector<SeatLabel> toSeatList(
    const oatpp::Object<BookingRequestDto>& _body)
{
    if (_body.get() == nullptr) {
        throw invalidArgument("a JSON request body is required");
    }
    if (_body->seats.get() == nullptr || _body->seats->empty()) {
        throw invalidArgument("field 'seats' must list at least one seat");
    }

    std::vector<SeatLabel> seats;
    seats.reserve(_body->seats->size());

    for (std::size_t i = 0; i < _body->seats->size(); ++i) {
        const oatpp::String& seat = (*_body->seats)[i];
        if (seat.get() == nullptr || seat->empty()) {
            throw invalidArgument("field 'seats' contains an empty entry");
        }
        seats.push_back(*seat);
    }
    return seats;
}

/**
 * @brief Build a Movie from a request body.
 * @throws ServiceError InvalidArgument if required fields are missing.
 */
inline Movie toMovie(const oatpp::Object<MovieRequestDto>& _body)
{
    if (_body.get() == nullptr) {
        throw invalidArgument("a JSON request body is required");
    }

    Movie movie;
    movie.id = optionalString(_body->id);
    movie.title = requireString(_body->title, "title");
    movie.durationMinutes = optionalInt(_body->durationMinutes, 0);
    movie.language = optionalString(_body->language);
    movie.genre = optionalString(_body->genre);

    if (movie.durationMinutes <= 0) {
        throw invalidArgument("field 'duration_minutes' must be a positive integer");
    }
    return movie;
}

/**
 * @brief Build a Theater from a request body.
 *
 * A missing capacity becomes 0, which the catalog reads as "apply the
 * configured default".
 */
inline Theater toTheater(const oatpp::Object<TheaterRequestDto>& _body)
{
    if (_body.get() == nullptr) {
        throw invalidArgument("a JSON request body is required");
    }

    Theater theater;
    theater.id = optionalString(_body->id);
    theater.name = requireString(_body->name, "name");
    theater.city = optionalString(_body->city);
    theater.seatCapacity = optionalInt(_body->seatCapacity, 0);
    theater.seatsPerRow = optionalInt(_body->seatsPerRow, 0);

    if (theater.seatCapacity < 0 || theater.seatsPerRow < 0) {
        throw invalidArgument("seat capacity and seats per row must not be negative");
    }
    return theater;
}

/**
 * @brief Read the start time out of a showtime request body.
 * @throws ServiceError InvalidArgument if it is missing or not "HH:MM".
 */
inline MinutesSinceMidnight toStartTime(
    const oatpp::Object<ShowtimeRequestDto>& _body)
{
    if (_body.get() == nullptr) {
        throw invalidArgument("a JSON request body is required");
    }

    return schedule::parseTimeOfDay(requireString(_body->startTime, "start_time"));
}

}
}

#endif
