/**
 * @file ErrorHandler.cpp
 * @brief Implementation of the exception-to-HTTP mapping.
 */
#include "rest/ErrorHandler.hpp"

#include "moviebackend/Logging.hpp"
#include "rest/dto/Dtos.hpp"

#include <string>

#include "oatpp/core/parser/ParsingError.hpp"
#include "oatpp/web/protocol/http/outgoing/BufferBody.hpp"
#include "oatpp/web/protocol/http/outgoing/ResponseFactory.hpp"

namespace moviebackend {
namespace rest {
namespace http = oatpp::web::protocol::http;

RestErrorHandler::RestErrorHandler(
    const std::shared_ptr<oatpp::data::mapping::ObjectMapper>& _objectMapper)
    : m_objectMapper(_objectMapper)
{
}

http::Status RestErrorHandler::toHttpStatus(ErrorCode _code)
{
    switch (_code) {
        case ErrorCode::NotFound:           return http::Status::CODE_404;
        case ErrorCode::InvalidArgument:    return http::Status::CODE_400;
        case ErrorCode::Conflict:           return http::Status::CODE_409;
        case ErrorCode::SeatUnavailable:    return http::Status::CODE_409;
        case ErrorCode::PersistenceFailure: return http::Status::CODE_500;
        case ErrorCode::Internal:           return http::Status::CODE_500;
    }
    return http::Status::CODE_500;
}

std::shared_ptr<http::outgoing::Response> RestErrorHandler::makeResponse(
    const http::Status& _status,
    const std::string& _code,
    const std::string& _message,
    const Headers& _headers)
{
    oatpp::Object<ErrorDto> body = ErrorDto::createShared();
    body->code = _code;
    body->message = _message;

    const oatpp::String serialised = m_objectMapper->writeToString(body);

    std::shared_ptr<http::outgoing::Response> response =
        http::outgoing::ResponseFactory::createResponse(_status, serialised);

    response->putHeaderIfNotExists("Content-Type", "application/json");

    for (const auto& header : _headers.getAll()) {
        response->putHeaderIfNotExists(header.first.toString(),
                                       header.second.toString());
    }

    return response;
}

std::shared_ptr<http::outgoing::Response> RestErrorHandler::handleError(
    const std::exception_ptr& _error)
{
    Headers noHeaders;

    try {
        if (_error != nullptr) {
            std::rethrow_exception(_error);
        }

        MB_LOG_ERROR("REST: error handler invoked with no exception");
        return makeResponse(http::Status::CODE_500,
                            toString(ErrorCode::Internal),
                            "internal error", noHeaders);

    } catch (const ServiceError& serviceError) {
        const http::Status status = toHttpStatus(serviceError.code());

        if (status.code >= 500) {
            MB_LOG_ERROR("REST: {} -> HTTP {}: {}",
                         toString(serviceError.code()), status.code,
                         serviceError.what());
        } else {
            MB_LOG_DEBUG("REST: {} -> HTTP {}: {}",
                         toString(serviceError.code()), status.code,
                         serviceError.what());
        }

        return makeResponse(status, toString(serviceError.code()),
                            serviceError.what(), noHeaders);

    } catch (const oatpp::parser::ParsingError& parsingError) {
        MB_LOG_DEBUG("REST: malformed JSON body -> HTTP 400: {}",
                     parsingError.what());

        return makeResponse(http::Status::CODE_400,
                            toString(ErrorCode::InvalidArgument),
                            std::string("malformed JSON request body: ")
                                + parsingError.what(),
                            noHeaders);

    } catch (oatpp::web::protocol::http::HttpError& httpError) {
        MB_LOG_DEBUG("REST: oatpp HttpError -> HTTP {}: {}",
                     httpError.getInfo().status.code, httpError.getMessage()->c_str());

        return makeResponse(httpError.getInfo().status,
                            toString(ErrorCode::InvalidArgument),
                            httpError.getMessage()->c_str(),
                            httpError.getHeaders());

    } catch (const std::exception& unexpected) {
        MB_LOG_ERROR("REST: unhandled exception: {}", unexpected.what());
        return makeResponse(http::Status::CODE_500,
                            toString(ErrorCode::Internal),
                            "internal error", noHeaders);

    } catch (...) {
        MB_LOG_ERROR("REST: unhandled non-standard exception");
        return makeResponse(http::Status::CODE_500,
                            toString(ErrorCode::Internal),
                            "internal error", noHeaders);
    }
}

std::shared_ptr<http::outgoing::Response> RestErrorHandler::handleError(
    const oatpp::web::protocol::http::Status& _status,
    const oatpp::String& _message,
    const Headers& _headers)
{
    const std::string text = (_message == nullptr) ? std::string("request failed")
                                                  : std::string(_message->c_str());

    MB_LOG_DEBUG("REST: framework error -> HTTP {}: {}", _status.code, text);

    const ErrorCode code = (_status.code == 404) ? ErrorCode::NotFound
                         : (_status.code < 500)  ? ErrorCode::InvalidArgument
                                                : ErrorCode::Internal;

    return makeResponse(_status, toString(code), text, _headers);
}

}
}
