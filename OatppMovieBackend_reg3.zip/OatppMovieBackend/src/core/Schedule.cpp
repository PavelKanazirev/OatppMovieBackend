/**
 * @file Schedule.cpp
 * @brief Time-of-day handling and default timeline generation.
 */
#include "moviebackend/Schedule.hpp"

#include "moviebackend/Errors.hpp"

#include <string>

namespace moviebackend {
namespace schedule {
namespace {
/** Minutes in a day; the upper bound for any time-of-day value. */
constexpr int kMinutesPerDay = 24 * 60;

/** Minutes in an hour. */
constexpr int kMinutesPerHour = 60;

/**
 * @brief Parse exactly two ASCII digits at @p offset.
 * @return the value, or -1 if the characters are not both digits.
 */
int parseTwoDigits(const std::string& _text, std::size_t _offset)
{
    const char high = _text[_offset];
    const char low  = _text[_offset + 1];

    if (high < '0' || high > '9' || low < '0' || low > '9') {
        return -1;
    }
    return (high - '0') * 10 + (low - '0');
}

}

MinutesSinceMidnight parseTimeOfDay(const std::string& _text)
{
    if (_text.size() != 5 || _text[2] != ':') {
        throw invalidArgument("time must be formatted as HH:MM, got '" + _text + "'");
    }

    const int hours   = parseTwoDigits(_text, 0);
    const int minutes = parseTwoDigits(_text, 3);

    if (hours < 0 || minutes < 0) {
        throw invalidArgument("time must be formatted as HH:MM, got '" + _text + "'");
    }
    if (hours > 23) {
        throw invalidArgument("hour must be 00..23, got '" + _text + "'");
    }
    if (minutes > 59) {
        throw invalidArgument("minute must be 00..59, got '" + _text + "'");
    }

    return hours * kMinutesPerHour + minutes;
}

std::string formatTimeOfDay(MinutesSinceMidnight _minutes)
{
    if (_minutes < 0 || _minutes >= kMinutesPerDay) {
        throw invalidArgument("time of day out of range: "
                              + std::to_string(_minutes) + " minutes");
    }

    const int hours = _minutes / kMinutesPerHour;
    const int mins  = _minutes % kMinutesPerHour;

    std::string result;
    result.reserve(5);
    result.push_back(static_cast<char>('0' + hours / 10));
    result.push_back(static_cast<char>('0' + hours % 10));
    result.push_back(':');
    result.push_back(static_cast<char>('0' + mins / 10));
    result.push_back(static_cast<char>('0' + mins % 10));
    return result;
}

MinutesSinceMidnight roundUpToWholeHour(MinutesSinceMidnight _minutes)
{
    const int remainder = _minutes % kMinutesPerHour;
    if (remainder == 0) {
        return _minutes;
    }
    return _minutes + (kMinutesPerHour - remainder);
}

std::vector<MinutesSinceMidnight> generateDefaultStartTimes(
    int _movieDurationMinutes,
    const ScheduleConfig& _config)
{
    if (_movieDurationMinutes <= 0) {
        throw invalidArgument("movie duration must be positive, got "
                              + std::to_string(_movieDurationMinutes));
    }
    if (_config.dayStart < 0 || _config.dayStart >= kMinutesPerDay) {
        throw invalidArgument("schedule day_start is outside the day");
    }
    if (_config.dayEnd < _config.dayStart) {
        throw invalidArgument("schedule day_end must not be before day_start");
    }

    std::vector<MinutesSinceMidnight> startTimes;

    MinutesSinceMidnight current = _config.dayStart;

    while (current <= _config.dayEnd) {
        startTimes.push_back(current);

        const MinutesSinceMidnight endOfScreening = current + _movieDurationMinutes;
        const MinutesSinceMidnight nextStart = roundUpToWholeHour(endOfScreening);

        if (nextStart >= kMinutesPerDay || nextStart <= current) {
            break;
        }
        current = nextStart;
    }

    return startTimes;
}

}
}
