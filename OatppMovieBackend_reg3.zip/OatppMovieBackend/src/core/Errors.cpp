/**
 * @file Errors.cpp
 * @brief Implementation of the error taxonomy helpers.
 */
#include "moviebackend/Errors.hpp"

namespace moviebackend {
const char* toString(ErrorCode _code) noexcept
{
    switch (_code) {
        case ErrorCode::NotFound:           return "NOT_FOUND";
        case ErrorCode::InvalidArgument:    return "INVALID_ARGUMENT";
        case ErrorCode::Conflict:           return "CONFLICT";
        case ErrorCode::SeatUnavailable:    return "SEAT_UNAVAILABLE";
        case ErrorCode::PersistenceFailure: return "PERSISTENCE_FAILURE";
        case ErrorCode::Internal:           return "INTERNAL";
    }
    return "INTERNAL";
}

ServiceError notFound(const std::string& _entity, const std::string& _id)
{
    return ServiceError(ErrorCode::NotFound,
                        "no such " + _entity + ": '" + _id + "'");
}

ServiceError invalidArgument(const std::string& _message)
{
    return ServiceError(ErrorCode::InvalidArgument, _message);
}

ServiceError conflict(const std::string& _message)
{
    return ServiceError(ErrorCode::Conflict, _message);
}

}
