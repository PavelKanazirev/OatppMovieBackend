/**
 * @file IdGenerator.cpp
 * @brief Implementation of the prefixed id generator.
 */
#include "moviebackend/IdGenerator.hpp"

#include <utility>

namespace moviebackend {
IdGenerator::IdGenerator(std::string _prefix)
    : m_prefix(std::move(_prefix))
{
}

std::string IdGenerator::next()
{
    std::uint64_t value = 0;

    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        ++m_counter;
        value = m_counter;
    }

    return m_prefix + std::to_string(value);
}

void IdGenerator::observeExistingId(const std::string& _existingId)
{
    if (_existingId.size() <= m_prefix.size()) {
        return;
    }
    if (_existingId.compare(0, m_prefix.size(), m_prefix) != 0) {
        return;
    }

    std::uint64_t parsed = 0;
    for (std::size_t i = m_prefix.size(); i < _existingId.size(); ++i) {
        const char c = _existingId[i];
        if (c < '0' || c > '9') {
            return;
        }

        const std::uint64_t digit =
            static_cast<std::uint64_t>(static_cast<unsigned char>(c) - '0');

        if (parsed > (UINT64_MAX - digit) / 10U) {
            return;
        }
        parsed = parsed * 10U + digit;
    }

    const std::lock_guard<std::mutex> guard(m_mutex);
    if (parsed > m_counter) {
        m_counter = parsed;
    }
}

std::uint64_t IdGenerator::current() const
{
    const std::lock_guard<std::mutex> guard(m_mutex);
    return m_counter;
}

}
