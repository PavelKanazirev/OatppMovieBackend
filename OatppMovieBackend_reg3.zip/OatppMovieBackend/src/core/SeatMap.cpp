/**
 * @file SeatMap.cpp
 * @brief Seat occupancy and the seat-label scheme.
 */
#include "moviebackend/SeatMap.hpp"

#include "moviebackend/Errors.hpp"

#include <cctype>
#include <string>

namespace moviebackend {
namespace {
/** We label rows 'a'..'z', so a layout may not need more than 26 rows. */
constexpr int kMaxRows = 26;

/**
 * @brief Hard upper bound on any layout dimension.
 *
 * A real auditorium has a few thousand seats at most. The bound exists for
 * two concrete reasons, both reachable from an unauthenticated admin request:
 *
 *   * it stops `seat_capacity: 2000000000` turning into a multi-gigabyte
 *     `std::vector` allocation, and
 *   * together with the 64-bit arithmetic below it makes the index
 *     calculations provably overflow-free.
 */
constexpr int kMaxLayoutDimension = 100000;

/**
 * @brief Number of rows needed for @p capacity seats at @p seatsPerRow each.
 *
 * Integer ceiling division, written out rather than using a helper so the
 * arithmetic is visible.
 *
 * Deliberately done in 64-bit: `(capacity + seatsPerRow - 1)` overflows a
 * 32-bit int for large inputs, and a wrapped negative numerator yields a
 * quotient of 0, which would sail straight past the 26-row check below.
 */
long long rowsNeeded(long long _capacity, long long _seatsPerRow)
{
    return (_capacity + _seatsPerRow - 1) / _seatsPerRow;
}

/**
 * @brief Validate a layout, throwing if it cannot be labelled or stored.
 */
void validateLayout(int _capacity, int _seatsPerRow)
{
    if (_capacity <= 0) {
        throw invalidArgument("seat capacity must be positive, got "
                              + std::to_string(_capacity));
    }
    if (_seatsPerRow <= 0) {
        throw invalidArgument("seats per row must be positive, got "
                              + std::to_string(_seatsPerRow));
    }
    if (_capacity > kMaxLayoutDimension) {
        throw invalidArgument("seat capacity must not exceed "
                              + std::to_string(kMaxLayoutDimension) + ", got "
                              + std::to_string(_capacity));
    }
    if (_seatsPerRow > kMaxLayoutDimension) {
        throw invalidArgument("seats per row must not exceed "
                              + std::to_string(kMaxLayoutDimension) + ", got "
                              + std::to_string(_seatsPerRow));
    }
    if (rowsNeeded(_capacity, _seatsPerRow) > kMaxRows) {
        throw invalidArgument(
            "layout needs more than 26 rows (capacity "
            + std::to_string(_capacity) + ", "
            + std::to_string(_seatsPerRow) + " per row); rows are labelled a..z");
    }
}

}

SeatMap::SeatMap(int _capacity, int _seatsPerRow)
    : m_capacity(_capacity)
    , m_seatsPerRow(_seatsPerRow)
    , m_seats()
{
    validateLayout(_capacity, _seatsPerRow);
    m_seats.assign(static_cast<std::size_t>(_capacity), SeatState::Free);
}

std::optional<std::size_t> SeatMap::labelToIndex(const SeatLabel& _label) const
{
    if (_label.size() < 2) {
        return std::nullopt;
    }

    const unsigned char rawRow = static_cast<unsigned char>(_label[0]);
    const int rowChar = std::tolower(rawRow);

    if (rowChar < 'a' || rowChar > 'z') {
        return std::nullopt;
    }
    const int rowIndex = rowChar - 'a';

    if (_label[1] == '0') {
        return std::nullopt;
    }

    int seatNumber = 0;
    for (std::size_t i = 1; i < _label.size(); ++i) {
        const char c = _label[i];
        if (c < '0' || c > '9') {
            return std::nullopt;
        }
        seatNumber = seatNumber * 10 + (c - '0');
        if (seatNumber > m_capacity) {
            return std::nullopt;
        }
    }

    if (seatNumber < 1 || seatNumber > m_seatsPerRow) {
        return std::nullopt;
    }

    const long long flatIndex =
        static_cast<long long>(rowIndex) * static_cast<long long>(m_seatsPerRow)
        + static_cast<long long>(seatNumber - 1);

    if (flatIndex < 0 || flatIndex >= static_cast<long long>(m_capacity)) {
        return std::nullopt;
    }

    return static_cast<std::size_t>(flatIndex);
}

SeatLabel SeatMap::indexToLabel(std::size_t _index) const
{
    if (_index >= static_cast<std::size_t>(m_capacity)) {
        throw invalidArgument("seat index out of range: " + std::to_string(_index));
    }

    const int flat = static_cast<int>(_index);
    const int rowIndex   = flat / m_seatsPerRow;
    const int seatNumber = flat % m_seatsPerRow + 1;

    SeatLabel label;
    label.push_back(static_cast<char>('a' + rowIndex));
    label += std::to_string(seatNumber);
    return label;
}

bool SeatMap::isFree(const SeatLabel& _label) const
{
    const std::optional<std::size_t> index = labelToIndex(_label);
    if (!index.has_value()) {
        return false;
    }
    return m_seats[*index] == SeatState::Free;
}

void SeatMap::book(const SeatLabel& _label)
{
    const std::optional<std::size_t> index = labelToIndex(_label);
    if (!index.has_value()) {
        throw notFound("seat", _label);
    }
    if (m_seats[*index] != SeatState::Free) {
        throw ServiceError(ErrorCode::SeatUnavailable,
                           "seat '" + _label + "' is already booked");
    }
    m_seats[*index] = SeatState::Booked;
}

void SeatMap::release(const SeatLabel& _label)
{
    const std::optional<std::size_t> index = labelToIndex(_label);
    if (!index.has_value()) {
        throw notFound("seat", _label);
    }
    m_seats[*index] = SeatState::Free;
}

std::vector<SeatLabel> SeatMap::availableSeats() const
{
    std::vector<SeatLabel> result;
    result.reserve(m_seats.size());

    for (std::size_t i = 0; i < m_seats.size(); ++i) {
        if (m_seats[i] == SeatState::Free) {
            result.push_back(indexToLabel(i));
        }
    }
    return result;
}

std::vector<SeatLabel> SeatMap::bookedSeats() const
{
    std::vector<SeatLabel> result;

    for (std::size_t i = 0; i < m_seats.size(); ++i) {
        if (m_seats[i] == SeatState::Booked) {
            result.push_back(indexToLabel(i));
        }
    }
    return result;
}

int SeatMap::availableCount() const noexcept
{
    int count = 0;
    for (std::size_t i = 0; i < m_seats.size(); ++i) {
        if (m_seats[i] == SeatState::Free) {
            ++count;
        }
    }
    return count;
}

void SeatMap::relayout(int _newCapacity, int _newSeatsPerRow)
{
    validateLayout(_newCapacity, _newSeatsPerRow);

    const std::vector<SeatLabel> booked = bookedSeats();

    SeatMap replacement(_newCapacity, _newSeatsPerRow);

    for (std::size_t i = 0; i < booked.size(); ++i) {
        const std::optional<std::size_t> index =
            replacement.labelToIndex(booked[i]);

        if (!index.has_value()) {
            throw conflict("cannot change layout to capacity "
                           + std::to_string(_newCapacity) + " / "
                           + std::to_string(_newSeatsPerRow)
                           + " per row: seat '" + booked[i]
                           + "' is booked and would no longer exist");
        }
        replacement.m_seats[*index] = SeatState::Booked;
    }

    *this = replacement;
}

}
