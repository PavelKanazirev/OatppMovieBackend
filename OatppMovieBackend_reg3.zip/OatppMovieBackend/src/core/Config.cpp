/**
 * @file Config.cpp
 * @brief Loading config.json with Boost.JSON.
 */
#include "moviebackend/Config.hpp"

#include "moviebackend/Errors.hpp"
#include "moviebackend/Schedule.hpp"
#include "persistence/JsonHelpers.hpp"

#include <fstream>
#include <sstream>

namespace moviebackend {
namespace {
/**
 * @brief Read a whole file into a string.
 * @throws ServiceError InvalidArgument if the file cannot be opened.
 */
std::string readWholeFile(const std::string& _path)
{
    std::ifstream stream(_path.c_str(), std::ios::in | std::ios::binary);
    if (!stream.is_open()) {
        throw invalidArgument("cannot open '" + _path + "' for reading");
    }

    std::ostringstream buffer;
    buffer << stream.rdbuf();

    if (stream.bad()) {
        throw invalidArgument("error while reading '" + _path + "'");
    }
    return buffer.str();
}

}

Config Config::loadFromString(const std::string& _json,
                              const std::string& _originForErrors)
{
    using namespace jsonhelpers;

    Config config;

    const boost::json::value document = parseDocument(_json, _originForErrors);
    const boost::json::object& root = *requireObject(document, _originForErrors, "<root>");

    const boost::json::object* server = optionalObject(root, "server", _originForErrors, "server");
    if (server != nullptr) {
        config.server.host = optionalString(*server, "host", config.server.host,
                                            _originForErrors, "server.host");

        const std::int64_t port = optionalInt(*server, "port", config.server.port,
                                              _originForErrors, "server.port");

        if (port < 0 || port > 65535) {
            throw invalidArgument(_originForErrors
                                  + ": field 'server.port' must be 0..65535");
        }
        config.server.port = static_cast<std::uint16_t>(port);
    }

    const boost::json::object* theaterDefaults =
        optionalObject(root, "theater_defaults", _originForErrors, "theater_defaults");
    if (theaterDefaults != nullptr) {
        config.theaterDefaults.seatCapacity = toInt(
            optionalInt(*theaterDefaults, "seat_capacity",
                        config.theaterDefaults.seatCapacity,
                        _originForErrors, "theater_defaults.seat_capacity"),
            _originForErrors, "theater_defaults.seat_capacity");

        config.theaterDefaults.seatsPerRow = toInt(
            optionalInt(*theaterDefaults, "seats_per_row",
                        config.theaterDefaults.seatsPerRow,
                        _originForErrors, "theater_defaults.seats_per_row"),
            _originForErrors, "theater_defaults.seats_per_row");

        if (config.theaterDefaults.seatCapacity <= 0) {
            throw invalidArgument(_originForErrors
                                  + ": field 'theater_defaults.seat_capacity' must be positive");
        }
        if (config.theaterDefaults.seatsPerRow <= 0) {
            throw invalidArgument(_originForErrors
                                  + ": field 'theater_defaults.seats_per_row' must be positive");
        }
    }

    const boost::json::object* scheduleObject =
        optionalObject(root, "schedule", _originForErrors, "schedule");
    if (scheduleObject != nullptr) {
        const std::string dayStart =
            optionalString(*scheduleObject, "day_start",
                           schedule::formatTimeOfDay(config.schedule.dayStart),
                           _originForErrors, "schedule.day_start");
        const std::string dayEnd =
            optionalString(*scheduleObject, "day_end",
                           schedule::formatTimeOfDay(config.schedule.dayEnd),
                           _originForErrors, "schedule.day_end");

        config.schedule.dayStart = schedule::parseTimeOfDay(dayStart);
        config.schedule.dayEnd = schedule::parseTimeOfDay(dayEnd);

        if (config.schedule.dayEnd < config.schedule.dayStart) {
            throw invalidArgument(_originForErrors
                                  + ": 'schedule.day_end' must not be before 'schedule.day_start'");
        }
    }

    const boost::json::object* catalog =
        optionalObject(root, "catalog", _originForErrors, "catalog");
    if (catalog != nullptr) {
        config.catalog.path = optionalString(*catalog, "path", config.catalog.path,
                                             _originForErrors, "catalog.path");
        config.catalog.autosave = optionalBool(*catalog, "autosave",
                                               config.catalog.autosave,
                                               _originForErrors, "catalog.autosave");
        config.catalog.autosaveDebounceMs = toInt(
            optionalInt(*catalog, "autosave_debounce_ms",
                        config.catalog.autosaveDebounceMs,
                        _originForErrors, "catalog.autosave_debounce_ms"),
            _originForErrors, "catalog.autosave_debounce_ms");

        if (config.catalog.autosaveDebounceMs < 0) {
            throw invalidArgument(_originForErrors
                                  + ": field 'catalog.autosave_debounce_ms' must not be negative");
        }
    }

    const boost::json::object* logging =
        optionalObject(root, "logging", _originForErrors, "logging");
    if (logging != nullptr) {
        config.logging.level = optionalString(*logging, "level", config.logging.level,
                                              _originForErrors, "logging.level");
        config.logging.file = optionalString(*logging, "file", config.logging.file,
                                             _originForErrors, "logging.file");
        config.logging.pattern = optionalString(*logging, "pattern",
                                                config.logging.pattern,
                                                _originForErrors, "logging.pattern");
    }

    return config;
}

Config Config::loadFromFile(const std::string& _path)
{
    return loadFromString(readWholeFile(_path), _path);
}

}
