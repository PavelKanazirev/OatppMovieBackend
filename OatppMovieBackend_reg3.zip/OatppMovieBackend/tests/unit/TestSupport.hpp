/**
 * @file TestSupport.hpp
 * @brief Helpers shared by the unit tests.
 */
#ifndef MOVIEBACKEND_TESTSUPPORT_HPP
#define MOVIEBACKEND_TESTSUPPORT_HPP

#include "moviebackend/CatalogStore.hpp"
#include "moviebackend/Domain.hpp"
#include "moviebackend/Errors.hpp"

#include <gtest/gtest.h>

#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

/**
 * @brief Assert that a statement throws a ServiceError carrying @p expected.
 *
 * gtest's EXPECT_THROW cannot inspect the exception, and the error *code* is
 * the part of the contract that matters - a NotFound where a Conflict was
 * meant is a real API bug that EXPECT_THROW would happily pass.
 */
#define EXPECT_SERVICE_ERROR(statement, expected)                             \
    do {                                                                      \
        try {                                                                 \
            statement;                                                        \
            FAIL() << "expected a ServiceError, none was thrown";             \
        } catch (const ::moviebackend::ServiceError& error) {                 \
            EXPECT_EQ(expected, error.code()) << error.what();                \
        }                                                                     \
    } while (false)

namespace moviebackend {
namespace testsupport {
/**
 * @brief A CatalogStore that keeps everything in memory.
 *
 * Design pattern: **Test Double** (a fake, not a mock - it has working
 * behaviour). Lets the persistence tests run with no filesystem at all, which
 * keeps them fast and free of temp-directory cleanup.
 *
 * Thread safe, because PersistenceWorker calls save() from its own thread
 * while the test thread reads the counters.
 */
class InMemoryCatalogStore : public CatalogStore {
public:
    InMemoryCatalogStore() = default;

    CatalogSnapshot load() override
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        ++m_loadCount;
        return m_snapshot;
    }

    void save(const CatalogSnapshot& _snapshot) override
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        if (m_failNextSave || m_failAllSaves) {
            m_failNextSave = false;
            throw ServiceError(ErrorCode::PersistenceFailure,
                               "InMemoryCatalogStore was told to fail");
        }
        m_snapshot = _snapshot;
        ++m_saveCount;
    }

    /** @brief Seed the store with state that load() will return. */
    void seed(const CatalogSnapshot& _snapshot)
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        m_snapshot = _snapshot;
    }

    /** @return the most recently saved (or seeded) state. */
    CatalogSnapshot stored() const
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        return m_snapshot;
    }

    std::size_t saveCount() const
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        return m_saveCount;
    }

    std::size_t loadCount() const
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        return m_loadCount;
    }

    /** @brief Make the next save() throw, to cover the error path. */
    void failNextSave()
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        m_failNextSave = true;
    }

    /**
     * @brief Make every save() throw until switched off again.
     *
     * Models a full or read-only disk, which is the case where "a failed write
     * is silently treated as success" turns into real data loss.
     */
    void failAllSaves(bool _fail)
    {
        const std::lock_guard<std::mutex> guard(m_mutex);
        m_failAllSaves = _fail;
    }

private:
    mutable std::mutex m_mutex;
    CatalogSnapshot    m_snapshot;
    std::size_t        m_saveCount = 0;
    std::size_t        m_loadCount = 0;
    bool               m_failNextSave = false;
    bool               m_failAllSaves = false;
};

/** @brief Build a Movie without repeating the field names in every test. */
inline Movie makeMovie(const std::string& _id,
                       const std::string& _title,
                       int _durationMinutes)
{
    Movie movie;
    movie.id = _id;
    movie.title = _title;
    movie.durationMinutes = _durationMinutes;
    movie.language = "EN";
    movie.genre = "Test";
    return movie;
}

/** @brief Build a Theater without repeating the field names in every test. */
inline Theater makeTheater(const std::string& _id,
                           const std::string& _name,
                           int _seatCapacity,
                           int _seatsPerRow)
{
    Theater theater;
    theater.id = _id;
    theater.name = _name;
    theater.city = "Testville";
    theater.seatCapacity = _seatCapacity;
    theater.seatsPerRow = _seatsPerRow;
    return theater;
}

/** @return true if @p values contains @p wanted. */
inline bool contains(const std::vector<std::string>& _values,
                     const std::string& _wanted)
{
    for (std::size_t i = 0; i < _values.size(); ++i) {
        if (_values[i] == _wanted) {
            return true;
        }
    }
    return false;
}

}
}

#endif
