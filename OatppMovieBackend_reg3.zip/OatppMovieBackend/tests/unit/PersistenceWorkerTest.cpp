/**
 * @file PersistenceWorkerTest.cpp
 * @brief Tests for the background writer thread.
 *
 * These tests are all about *timing*, which makes them the easiest ones in
 * the suite to write in a flaky way. The rule followed here: never assert
 * "this happened within N milliseconds". Instead, drive the worker and then
 * block on waitForIdle(), which is a condition-variable wait rather than a
 * sleep. The only timeouts present are generous upper bounds whose expiry
 * means a genuine failure (a deadlock), not a slow machine.
 */
#include "moviebackend/PersistenceWorker.hpp"

#include "moviebackend/Catalog.hpp"
#include "TestSupport.hpp"

#include <gtest/gtest.h>

#include <chrono>
#include <memory>

using moviebackend::Catalog;
using moviebackend::CatalogSnapshot;
using moviebackend::PersistenceWorker;
using moviebackend::Showtime;
using moviebackend::TheaterDefaults;
using moviebackend::testsupport::InMemoryCatalogStore;
using moviebackend::testsupport::makeMovie;
using moviebackend::testsupport::makeTheater;

namespace {
/** Generous - its expiry means a hang, not a slow machine. */
constexpr std::chrono::milliseconds kFlushTimeout(10000);

class PersistenceWorkerTest : public ::testing::Test {
protected:
    PersistenceWorkerTest()
        : m_defaults()
        , m_catalog(m_defaults)
        , m_store()
    {
    }

    void seedCatalog()
    {
        m_catalog.addMovie(makeMovie("m1", "Persisted", 100));
        m_catalog.addTheater(makeTheater("t1", "Hall", 20, 10));

        Showtime showtime;
        showtime.id = "s1";
        showtime.movieId = "m1";
        showtime.theaterId = "t1";
        showtime.startTime = 9 * 60;
        m_catalog.addShowtime(showtime);
    }

    TheaterDefaults       m_defaults;
    Catalog               m_catalog;
    InMemoryCatalogStore  m_store;
};

TEST_F(PersistenceWorkerTest, ChangesReachTheStoreWithoutAnyPolling)
{
    PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(0));

    m_catalog.addMovie(makeMovie("m1", "Written", 100));

    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout)) << "the worker never caught up";

    const CatalogSnapshot stored = m_store.stored();
    ASSERT_EQ(1u, stored.movies.size());
    EXPECT_EQ("Written", stored.movies[0].title);
}

TEST_F(PersistenceWorkerTest, ABurstOfChangesIsCoalescedIntoFewerWrites)
{
    PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(50));

    for (int i = 0; i < 50; ++i) {
        m_catalog.addMovie(makeMovie("", "Movie " + std::to_string(i), 100));
    }

    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout));

    EXPECT_EQ(50u, m_store.stored().movies.size());

    EXPECT_LT(m_store.saveCount(), 25u)
        << "the debounce did not coalesce anything";
    EXPECT_GT(m_store.saveCount(), 0u);
}

TEST_F(PersistenceWorkerTest, BookingsArePersisted)
{
    seedCatalog();

    PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(0));

    m_catalog.bookSeats("s1", {"a1", "a2"}, "Alice");

    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout));

    const CatalogSnapshot stored = m_store.stored();
    ASSERT_EQ(1u, stored.showtimes.size());
    EXPECT_EQ(2u, stored.showtimes[0].bookedSeats.size());
    ASSERT_EQ(1u, stored.bookings.size());
    EXPECT_EQ("Alice", stored.bookings[0].customerName);
}

TEST_F(PersistenceWorkerTest, ShutdownFlushesAnythingStillPending)
{
    {
        PersistenceWorker worker(m_catalog, m_store,
                                 std::chrono::milliseconds(60000));
        m_catalog.addMovie(makeMovie("m1", "Flushed On Exit", 100));
    }

    const CatalogSnapshot stored = m_store.stored();
    ASSERT_EQ(1u, stored.movies.size());
    EXPECT_EQ("Flushed On Exit", stored.movies[0].title);
}

TEST_F(PersistenceWorkerTest, DestructionWithNoChangesWritesNothing)
{
    {
        PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(0));
    }
    EXPECT_EQ(0u, m_store.saveCount());
}

TEST_F(PersistenceWorkerTest, AFailingStoreDoesNotBringDownTheService)
{
    PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(0));

    m_store.failNextSave();
    m_catalog.addMovie(makeMovie("m1", "First", 100));
    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout));

    m_catalog.addMovie(makeMovie("m2", "Second", 100));
    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout));

    EXPECT_EQ(2u, m_store.stored().movies.size());
}

TEST_F(PersistenceWorkerTest, AFailedSaveIsNotReportedAsProgressAndIsRetried)
{
    PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(0));

    m_store.failAllSaves(true);
    m_catalog.addMovie(makeMovie("m1", "Never Written", 100));

    EXPECT_FALSE(worker.waitForIdle(std::chrono::milliseconds(400)))
        << "waitForIdle() reported success for a write that never happened";
    EXPECT_EQ(0u, m_store.saveCount());

    m_store.failAllSaves(false);

    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout))
        << "the worker never retried after the store recovered";

    const CatalogSnapshot stored = m_store.stored();
    ASSERT_EQ(1u, stored.movies.size());
    EXPECT_EQ("Never Written", stored.movies[0].title);
}

TEST_F(PersistenceWorkerTest, APermanentlyFailingStoreDoesNotSpinOrHangShutdown)
{
    m_store.failAllSaves(true);

    {
        PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(0));
        m_catalog.addMovie(makeMovie("m1", "Doomed", 100));
        EXPECT_FALSE(worker.waitForIdle(std::chrono::milliseconds(600)));
    }

    EXPECT_EQ(0u, m_store.saveCount());
}

TEST_F(PersistenceWorkerTest, UnregistersItselfSoTheCatalogCanOutliveIt)
{
    {
        PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(0));
        m_catalog.addMovie(makeMovie("m1", "Before", 100));
        ASSERT_TRUE(worker.waitForIdle(kFlushTimeout));
    }

    EXPECT_NO_THROW(m_catalog.addMovie(makeMovie("m2", "After", 100)));

    EXPECT_EQ(1u, m_store.stored().movies.size());
}

TEST_F(PersistenceWorkerTest, ConcurrentBookingsAllReachTheStore)
{
    seedCatalog();

    PersistenceWorker worker(m_catalog, m_store, std::chrono::milliseconds(10));

    const int threadCount = 8;
    std::vector<std::thread> threads;

    for (int t = 0; t < threadCount; ++t) {
        const std::string seat = "a" + std::to_string(t + 1);
        threads.push_back(std::thread([this, seat]() {
            try {
                m_catalog.bookSeats("s1", {seat}, "racer");
            } catch (const moviebackend::ServiceError&) {
            }
        }));
    }
    for (std::size_t i = 0; i < threads.size(); ++i) {
        threads[i].join();
    }

    ASSERT_TRUE(worker.waitForIdle(kFlushTimeout));

    const CatalogSnapshot stored = m_store.stored();
    ASSERT_EQ(1u, stored.showtimes.size());
    EXPECT_EQ(m_catalog.listBookedSeats("s1").size(),
              stored.showtimes[0].bookedSeats.size());
    EXPECT_EQ(m_catalog.listBookings().size(), stored.bookings.size());
}

}
